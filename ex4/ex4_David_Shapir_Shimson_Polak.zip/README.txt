=====================================================================

OOP, ex4
========
by: David Sapir & Shimson Polak 
id: David - 208917351
    Shimson - 315605642 


	            Load Runner Map Editor.
=====================================================================

  			   Description
                        =================	
This map editor mimcs the Load Runner Game.
The theme of the editor is based on a popular game named "Devil May Cry"
==========================================================================


			 Design
                      ==============
MapEditor - 
Role: Responsible to display the window with the wanted display.
i.e.the map editor is responsible for editing the costumize map.

The class holds the objects Menu and Board which with he 
communicates with to accomplish his tasks and display the
wanted map to the user. 
Also, the MapEditor holds the game object textures.


Menu - 
Role: The Menu of the game holds 9 Buttons
      to control the map editing. 

Six out of nine (of the buttons), have the functionality of 
setting an object into the board/map of the game.

Game objects can be override aswell with clicking the
buttons delete and clear.
The map and all the seted obejcts can be saved with clickin the  
the save button.
(more info about the buttons functionality is presented below).

The menu, sends the icons to MapEditor, that afterward sends it to Board class.
Each icon that reprasant a texture in the board/map of the game. 
The class holds a pointer to a vector of the textures which is saved in the
MapEditor class. 
 

Each Button do the following:
note!: appearance of the buttons in the map editr according to the list.
Object buttons:
	1.Player(red coat) - allowing to put the player game object on table only if no player existed.
	2.Enemy(monster) - allowing to put the monsters/enemies in the map.
	3.Coin(red ball) - allowing to put the coin in the map.
	4.Block - allowing to put the block/floor/walls in the map.
	5.Ladder - allowing to put the ladder in the map.
	6.Pipe - allowing to put the pipe in the map.
operation button:
	7.Save - allowing to save the map in file Board.txt.
	8.Delete - allowing to delete a single object in the board.
	9.Clear - allowing to delete all the object in the board.


Button -
Role:The Button is member of the menu that hold reprasant each
different operation/object used in the map.


Board - 
Role:The Board is responsible for the costumization of the map. 
The data,is shown as a 2D metrix/table. The Board hold a 2D vector
of object BoardCell, that each reprasant a location on the map.
The class hold a pointer to the textures saved in MapEditor and
sending the requested image to each cell.The cells textures are
chosen acording to an icon recived from MapEditor by Button pressed.


BoardCell -
Role::The BoardCell hold a single texture that reprasant a single
object existed in the game.


=======================================================================

                         Included files
                        =================
There are 5 object files built by us:
1.)MapEditor.cpp - Run the map editor window and communicate between Board
and Menu classes. 

2.)Menu.cpp - Hold buttons of game objects and required operations in the map editor.

3.)Button.cpp - For visual and for click area.

4.)Board.cpp -  Hold the map of the load runner game data.

5.)BoardCell.cpp - a single cell/area existed in the map world.

6.)Macros.h - hold the const used in the files.

Also every '.cpp' file has a header file.
5 source + 6 header =  11 files in total.

note:Resources diractory included as well to hold the images data used in the map editor.

                           Data Structure
                           ==============
None to mention.

=====================================================================
			
                           Algorithms worth mention:
                        =============================
None to mention.

=====================================================================

			    Known bugs
 	            =============================
None has been found.

=====================================================================
			    Comments
=====================================================================
1.) If no board.txt file existed,
    the user will be requseted to enter height and width size,
    note: recommended for good user experience to put 20 x 20 size.

2.) The window starting size is 1400x900 though can be scaled
    as the window is responsive according to the size.

3.) The user can put an game object(as described) by pressing once
    on the wanted button which will be marked as yellow,
    and allowing to put the object on the red mark on the map.

4.) If player object picked and putted once on board,the player
    wont be allowed to put another player object,and a red
    frame will apear on the player buttton. other object can be
    put multiple times.

5.) The usere can override a cell in the board table with
    differnt game object.

6.) If the user put the mouse betweem two marked cells, will
    allow to put multiple items, objects on the board(up to 4),
    except of the player which be allowed only once, even if
    pressed between multiple cells.

8.) If pressed save button , a save notification will be
    shown until other button pressed.

8.) The red ball repreasant a coin because of game design follow
    up the theme choosed. 

9.) Clear and save buttons will be marked yellow only once.

10.) Warning!! witout saving all data added on the map
     will be lost.

11.) Recommendation, for better user experience, use the map 
     we have given.