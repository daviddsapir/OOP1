//-------------- include section ----------------
#include "Board.h"
#include "Macros.h"
#include <fstream>


// c-tor
Board::Board(const int height, const int width,
	std::vector<sf::Texture>* textures)
	:m_height(height), m_width(width), m_textures(textures)
{
	m_bacgroundTexture.loadFromFile("background.png");
	setBoard();
}


// c-tor
Board::Board(std::vector<sf::Texture>* textures)
	:Board(DEFULT_SIZE, DEFULT_SIZE,textures)
{}


//-------------------- intilizeMap -------------------------
// set the map height, witdh and defaults.
//----------------------------------------------------------
void Board::intilizeMap(const int height, const int width)
{
	m_height = height;
	m_width = width;

	playerExist = false;

	m_table.clear();

	setBoard();
}


//------------------- setBoardData --------------------
// sets the data of the map form an external file
//---------------------------------------------------
void Board::setBoardData(std::ifstream &file)
{
	char icon;

	for (int row = 0; row < m_height; row++) {
		for (int col = 0; col < m_width; col++) {
			icon = file.get();

			if (icon == PLAYER_ICON)
				playerExist = true;

			m_table[row][col].setIcon(icon);
		}

		icon = file.get();
	}
}


//----------------------- getIsPlayerExist ---------------------
//get member is playerExist
//------------------------------------------------------
const bool Board::getIsPlayerExist()
{
	return playerExist;
}


/*-------------------- setCellTextureByIcon ----------------------
This function sets the need texture in the right place in the 
board according to icon.
The function recives a row and col in the board and sets the
needed texture in the needed index of the board (cell in the board
is a button object).
-----------------------------------------------------------------*/
void Board::setCellTextureByIcon(const char icon,
	const int row,
	const int col)
{
	switch (icon) {
	case PLAYER_ICON:
		m_table[row][col].setCellTexture(&(*m_textures)[PLAYER]);
		break;
	case ENEMY_ICON:
		m_table[row][col].setCellTexture(&(*m_textures)[ENEMY]);
		break;
	case COIN_ICON:
		m_table[row][col].setCellTexture(&(*m_textures)[COIN]);
		break;
	case LADDER_ICON:
		m_table[row][col].setCellTexture(&(*m_textures)[LADDER]);
		break;
	case PIPE_ICON:
		m_table[row][col].setCellTexture(&(*m_textures)[PIPE]);
		break;
	case BLOCK_ICON:
		m_table[row][col].setCellTexture(&(*m_textures)[BLOCK]);
		break;
	default:
		m_table[row][col].setCellTexture(NULL);
		break;
	}
}


/*---------------------------- Board --------------------------------
This function draws the the board by running all over it's cell 
and by calling an auxillary function named getBackgroundShape() 
that build the object with the currents cell Characteristics.
-------------------------------------------------------------------*/
void Board::draw(sf::RenderWindow& window)
{
	window.draw(getBackgroundShape());

	for (int i = 0; i < m_height; i++) {
		for (int j = 0; j < m_width; j++) {
			setCellTextureByIcon(m_table[i][j].getIcon(), i, j);
			window.draw(m_table[i][j].getShape());
		}
	}
}


//------------------- mouseHoverBoardHandler --------------------
// handles the situation that the mouse is over the board.
//---------------------------------------------------------------
void Board::mouseHoverBoardHandler(const sf::Vector2f& location,
	sf::RenderWindow& window)
{
	for (int i = 0; i < m_height; i++)
		for (int j = 0; j < m_width; j++)
			m_table[i][j].mouseHoverTableCell(location);
}


/*------------------------- getBackgroundShape -------------------------
This function builds a rectangle object with the wanted Characteristics
that we hold in the board class.
----------------------------------------------------------------------*/
sf::RectangleShape Board::getBackgroundShape()
{
	sf::RectangleShape temp_rec = 
		sf::RectangleShape({ BOARD_WIDTH_SIZE ,BOARD_HEIGHT_SIZE });
	temp_rec.setFillColor(sf::Color::White);
	temp_rec.setPosition(BEGIN_BOARD_POSITION_X, BEGIN_BOARD_POSITION_Y);
	temp_rec.setTexture(&m_bacgroundTexture);
	return temp_rec;
}



//----------------------------- setBoard -------------------------------
// Auxillary function that sets the board vector.
// The function, runs over the vector BoardCell and Initializes their 
// size.
//----------------------------------------------------------------------
void Board::setBoard()
{
	m_table.resize(m_height);

	for (int i = 0; i < m_height; i++) {

		m_table[i] = vector<BoardCell>(m_width);

		for (int j = 0; j < m_width; j++)
			m_table[i][j] = BoardCell((BOARD_WIDTH_SIZE/ m_width),
					(BOARD_HEIGHT_SIZE / m_height),j,i);

	}
}


//----------------------------- setBoardCellIcon -------------------------------
// auxillary function that sets the board cell icon.
//----------------------------------------------------------------------
void Board::setBoardCellIcon(const char icon,const int row,const int col)
{
	//first time putted player on board.
	if (icon == PLAYER_ICON && !playerExist) {
		m_table[row][col].setIcon(icon);
		playerExist = true;
	}
	//override player icon.
	else if (icon != PLAYER_ICON && m_table[row][col].getIcon() == PLAYER_ICON) {
		m_table[row][col].setIcon(icon);
		playerExist = false;
	}
	//put other icon on board.
	else if (icon != PLAYER_ICON )
		m_table[row][col].setIcon(icon);
}


//----------------------- getWidth ---------------------
// returns the width of the board.
//------------------------------------------------------
const int Board::getWidth() 
{
	return m_width;
}


//--------------------- getHeight ----------------------
// returns the width of the board.
//------------------------------------------------------
const int Board::getHeight()
{
	return m_height;
}


//--------------------- getCell ------------------------- 
// The function, returns the current cell in the board.
//-------------------------------------------------------
BoardCell Board::getCell(const int row,const int col)
{
	return m_table[row][col];
}


//----------------- mouseButtonReleasedHandler ----------------------
// The function, handles the event that the mouse button has been
// released
//-------------------------------------------------------------------
void Board::mouseButtonReleasedHandler(const sf::Vector2f& location,
	sf::RenderWindow& window,const char icon){
	
	if(icon != NOTHING_ICON){
		for (int i = 0; i < m_height; i++) {

			for (int j = 0; j < m_width; j++) 
				if (m_table[i][j].getShape().getGlobalBounds()
					.contains(location)) 
					setBoardCellIcon(icon,i,j);
				
		}
	}
}

