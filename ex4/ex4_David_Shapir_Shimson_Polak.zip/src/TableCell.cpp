
//-------------- include section ---------------
#include "TableCell.h"
#include "Macros.h"


// c-tor
TableCell::TableCell(const float width, const float height,const int col,const int row )
	:m_width(width),m_height(height),m_col(col),m_row(row),m_icon(' '),m_texture(NULL),
	m_color(sf::Color::Black)
{}


//---------------- setIcon -----------------
// Set the icon
//------------------------------------------
void TableCell::setIcon(const char icon) {
	if(icon !=NOTHING_ICON)
		m_icon = icon;
}


//-------------- getIcon ----------------
// Set the icon
//---------------------------------------
const char TableCell::getIcon() {
	return m_icon;
}


//------------------- setCellTexture ---------------------
// Sets the current wanted cells texture 
//--------------------------------------------------------
void TableCell::setCellTexture( sf::Texture *texture) {
	m_texture = texture;
}


//---------------------- mouseHoverTableCell ----------------------
// Handles the situation the the mouse is over the table cell
//-----------------------------------------------------------------
void TableCell::mouseHoverTableCell(const sf::Vector2f& location)
{
	if (getShape().getGlobalBounds().contains(location))
	{
		setOutlineColor(sf::Color::Red);
	}
	else
	{
		setOutlineColor(sf::Color::Black);
	}
}


//---------------------- setOutlineColor ------------------------
// Sets the outline color of the current cell the mouse is over.
//---------------------------------------------------------------
void TableCell::setOutlineColor(const sf::Color color)
{
	m_color = sf::Color(color);
}


//-------------------- getOutlineColor -------------------
// Returns the outline color
//--------------------------------------------------------
sf::Color TableCell::getOutlineColor() const {
	return m_color;
}


//----------------------- getShape --------------------------
// Return the shape with the needed characteristics
//-----------------------------------------------------------
sf::RectangleShape TableCell::getShape() {
	sf::RectangleShape temp_rec =
		sf::RectangleShape(sf::Vector2f(m_width, m_height));

	temp_rec.setPosition(m_col * m_width +
		(0.2 * WINDOW_WIDTH), m_row * m_height);
	temp_rec.setOutlineThickness(2);
	temp_rec.setOutlineColor(getOutlineColor());

	if (m_texture == NULL) {
		temp_rec.setFillColor(sf::Color::Transparent);
	}
	else {
		temp_rec.setFillColor(sf::Color::White);
		temp_rec.setTexture(&(*m_texture));
	}

	return temp_rec;
}


