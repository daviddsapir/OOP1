#include "Button.h"


// c-tor
Button::Button(const int& x, const int& y)
	:m_position(x,y),
	m_outlineThickness(DEFAULT_BUTTON_THICKNESS),
	m_outLineColor(sf::Color::Black)
{}


//------------------- setPosition --------------------------
// sets the position of the button
//----------------------------------------------------------
void Button::setPosition(const double& x, const double& y)
{
	m_position.x = x;
	m_position.y = y;
}


//---------------------- draw --------------------------- 
// Draws the button obejct
//-------------------------------------------------------
void Button::draw(sf::RenderWindow& window) const
{
	window.draw(createShape());
}


//-------------------- setShapeSize -------------------------
// Sets the shape of the size
//-----------------------------------------------------------
void Button::setShapeSize(const double& x, const double& y)
{
	m_shapeSize.x = x;
	m_shapeSize.y = y;
}


//-------------------- getShapeSize -------------------
// Return the shape size
//-----------------------------------------------------
const sf::Vector2f& Button::getShapeSize() const
{
	return m_shapeSize;
}


//---------------------- mouseHover ----------------------------
// Reutrns if the mouse is over the button
//--------------------------------------------------------------
bool Button::mouseHover(const sf::Vector2f& location)
{
	return (createShape().getGlobalBounds().contains(location));
}


//--------------------- setOutlineColor ---------------------
// Sets the outline color 
//-----------------------------------------------------------
void Button::setOutlineColor(const sf::Color& color)
{
	m_outLineColor = color;
}


//---------------- setTexture ------------------
// Set the wanted texture 
//----------------------------------------------
void Button::setColor(const sf::Color& color)
{
	m_color = color;
}


//---------------- setTexture ------------------
// Set the wanted texture 
//----------------------------------------------
void Button::setTexture(sf::Texture* texture)
{
	m_texture = texture;
}


//----------------- getOutlineColor -----------------
// Return the outline color 
//---------------------------------------------------
sf::Color Button::getOutlineColor() const
{
	return m_outLineColor;
}


//-------------- setOutlineThickness ------------------
// Set the outline thickness
//-----------------------------------------------------
void Button::setOutlineThickness(const int& thickness)
{
	m_outlineThickness = thickness;
}


//---------------- getOutlineThickness -------------
// Return the outline thickness
//--------------------------------------------------
int Button::getOutlineThickness() const
{
	return m_outlineThickness;
}



//------------------- createShape ---------------------
// Auxillary function the create the shape with
// wanted Characteristics
//-----------------------------------------------------
sf::RectangleShape Button::createShape() const
{
	auto shape = sf::RectangleShape(getShapeSize());
	shape.setPosition(m_position);
	shape.setOutlineThickness(getOutlineThickness());
	shape.setOutlineColor(getOutlineColor());
	shape.setTexture(m_texture);
	shape.setFillColor(m_color);
	
	return shape;
}