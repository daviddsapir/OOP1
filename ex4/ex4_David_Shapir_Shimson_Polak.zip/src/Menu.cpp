//-------- include section ---------
#include "menu.h"      

// c - tor
Menu::Menu(std::vector<sf::Texture>* textures) :m_textures(textures)
{}
//endof c-tor  


//---------------- draw --------------------
// Draws the menu
//-----------------------------------------
void Menu::draw(sf::RenderWindow& window) 
{
	window.draw(createMenu());
    drawButtons(window);
    drawMenuText(window);
}


//--------------------------------------------------------------
// Handles the event that the mouse is over the menu
//--------------------------------------------------------------
void Menu::mouseHoverHandlerMenu(const sf::Vector2f& location,
    sf::RenderWindow& window)
{
    for (int i = 0; i < BUTTON_AMOUNT; i++)
    {
        if (m_button[i].mouseHover(location))
            m_button[i].setOutlineThickness(BUTTON_MOUSE_HOVER_THICKNESS);
        else
            m_button[i].setOutlineThickness(DEFAULT_BUTTON_THICKNESS);
    }
}


//------------------- mouseButtonReleasedHandler -------------------
// Handle all buttons clicked event according to the button
// clicked.
//------------------------------------------------------------------
void Menu::mouseButtonReleasedHandler(const sf::Vector2f& location,
    sf::RenderWindow& window, char& icon)
{
    icon = getButtonIcon(location);

    if (icon != NOTHING_ICON)
        for (int i = 0; i < BUTTON_AMOUNT; i++)
        {
            if (m_button[i].mouseHover(location))
                m_button[i].setOutlineColor(sf::Color::Yellow);
            else
                m_button[i].setOutlineColor(sf::Color::Black);
        }
}


//------------------------- createMenu ----------------------------
// Create the menu by the wanted Characteristics
//-----------------------------------------------------------------
sf::RectangleShape Menu::createMenu() const
{
	auto shape = sf::RectangleShape({ MENU_WIDTH , WINDOW_WIDTH });
    shape.setFillColor(sf::Color(GREY));
	return shape;
}


//-------------- drawButtons ----------------
// Draws the buttons of the menu.
//-------------------------------------------
void Menu::drawButtons(sf::RenderWindow& window)
{
    sf::Vector2f position;
    position.x = 0;
    position.y = 0;

    for (int i = 0; i < BUTTON_AMOUNT; i++) {
        m_button[i].setShapeSize(BUTTON_WIDTH_SIZE, BUTTON_HIGHT_SIZE);
        m_button[i].setPosition(getNextButtonPosition(position).x,
            getNextButtonPosition(position).y);
        m_button[i].setTexture(&(*m_textures)[i]);
        m_button[i].draw(window);
    }

    m_button[SAVE].setOutlineColor(sf::Color::Black);
    m_button[CLEAR].setOutlineColor(sf::Color::Black);
}


//--------------------- drawMenuText -----------------------
// Draw the menu text to the window in the menu space
//----------------------------------------------------------
void Menu::drawMenuText(sf::RenderWindow& window)
{
    auto font = sf::Font();
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    auto text = sf::Text("MENU", font);
    text.setPosition(MENU_FONT_POSITION_X, MENU_FONT_POSITION_Y);
    text.setColor(sf::Color::Black);
    text.setCharacterSize(MENU_FONT_SIZE);
    text.setOutlineThickness(MENU_FONT_THICK);
    text.setLetterSpacing(MENU_FONT_SPACE);
    text.setStyle(MENU_FONT_STYLE);
    window.draw(text);
}


//------------------------- getNextButtonPosition ------------------------
// Return the next button position 
//------------------------------------------------------------------------
sf::Vector2f& Menu::getNextButtonPosition(sf::Vector2f& position) const
{
    if (position.x == 0 && position.y == 0)
    {
        position.x = BEGIN_BUTTON_POSITION_X;
        position.y = BEGIN_BUTTON_POSITION_Y;
    }
    else
    {
        position.y += BUTTON_MENU_SPACES;
    }

    return position;
}


//---------------- getButton ----------------
// Return button object in wanted index
//-------------------------------------------
Button Menu::getButton(const int index) {
    return m_button[index];
}


//------------------- getButtonIcon ---------------------
// Return the button icon in the menu
//-------------------------------------------------------
char Menu::getButtonIcon(const sf::Vector2f& location)
{
    if (getButton(PLAYER).mouseHover(location)) 
        return PLAYER_ICON;
    
    if (getButton(ENEMY).mouseHover(location))
        return ENEMY_ICON;
    
    if (getButton(COIN).mouseHover(location))
        return COIN_ICON;
    
   if (getButton(BLOCK).mouseHover(location)) 
        return BLOCK_ICON;

   if (getButton(PIPE).mouseHover(location))
       return PIPE_ICON;
  
   if (getButton(LADDER).mouseHover(location))
       return LADDER_ICON;
 
   if (getButton(SAVE).mouseHover(location))
       return SAVE_ICON;
 
   if (getButton(DELETE).mouseHover(location))
       return EMPTY_ICON;
   
   if (getButton(CLEAR).mouseHover(location))
       return CLEAR_ICON;

   return NOTHING_ICON;
}


//-------------------- setPlayerBtnColor ---------------------
// The function, checks if the player exists in the map.
// If he doesn't, then the button color of the button is
// seted as all buttons.
// If he does exists, then sets a different color to
// notify the user that only one player can be on the board.
//------------------------------------------------------------
void Menu::setPlayerBtnColor(const bool getIsPlayerExist,
    const char icon)
{
    if (getIsPlayerExist) {
        m_button[PLAYER].setColor(GREY);
        m_button[PLAYER].setOutlineColor(sf::Color::Red);
    }
    else {
        if (icon == PLAYER_ICON)
            m_button[PLAYER].setOutlineColor(sf::Color::Yellow);
        else
            m_button[PLAYER].setOutlineColor(sf::Color::Black);

        m_button[PLAYER].setColor(sf::Color::White);
    }
}