﻿
//---------- includes --------------
#include "mapEditor.h"
#include <iostream>
#include <string>


//-------------------- c-tor --------------------------
mapEditor::mapEditor()
    : m_window(sf::VideoMode( WINDOW_WIDTH,WINDOW_HIGHT),
        "Map Editor"),m_boradMap(&m_textures), m_menu(&m_textures)
{
    m_window.setVisible(false);
    saveTextures();
}


//----------------------- displayWindow ------------------------
// Displays the window.
// call this function from main to start the map editor.
//--------------------------------------------------------------
void mapEditor::displayWindow()
{    
    loadMapFile();

    m_window.setVisible(true);

    while (m_window.isOpen())
    {
        m_window.clear();
        draw();
        m_window.display();

        if (auto event = sf::Event{}; m_window.waitEvent(event))
        {
            switch (event.type)
            {
            case sf::Event::Closed:
                m_window.close();
                break;

            case sf::Event::MouseMoved:        
                mouseHoverHandler();
                break;

            case sf::Event::MouseButtonReleased:
                mouseButtonReleasedHandler();
                break;
            }
        }
    }
}



//------------------ draw -----------------------
// Draws the window with the help of auxillary 
// functions.
//-----------------------------------------------
void mapEditor::draw()
{
    m_boradMap.draw(m_window);

    m_menu.setPlayerBtnColor(m_boradMap.getIsPlayerExist(), m_icon);

    m_menu.draw(m_window);

    if (mapSaved) {
        displayMapSavedLogo();
    }
}



//----------------- displayMapSavedLogo ------------------
// The user pressed the button save ==> we will want 
// to display the user that the map has been saved
// successfully.
//--------------------------------------------------------
void mapEditor::displayMapSavedLogo() {
    auto font = sf::Font();
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    auto text = sf::Text("MAP SAVED", font);
    text.setPosition(SAVE_FONT_POSITION_X, SAVE_FONT_POSITION_Y);
    text.setColor(sf::Color::Red);
    text.setCharacterSize(SAVE_FONT_SIZE);
    text.setOutlineThickness(SAVE_FONT_THICK);
    text.setLetterSpacing(SAVE_FONT_SPACE);
    text.setStyle(SAVE_FONT_STYLE);
    m_window.draw(text);
}


//-------------------- mouseOnButtonHandler ---------------------
// Handles the event that the mouse is over an object
//---------------------------------------------------------------
void mapEditor::mouseHoverHandler()
{
    auto location =
        m_window.mapPixelToCoords(sf::Mouse::getPosition(m_window));

    m_menu.mouseHoverHandlerMenu(location, m_window);

    m_boradMap.mouseHoverBoardHandler(location, m_window);
}



//------------------ mouseButtonReleasedHandler ----------------
// Handles the event that the user realsed the 
// mouse button.
// The function sends to auxillary function the location that 
// the event of the mouse button realsed happed on the window.
// the auxillary function mouseButtonReleasedHandler returns 
// the icon that the user clicked with the mouse then we 
// check what icon has returned and act Accordingly.
// The function mouseButtonReleasedHandler gets the icon
// and displays it to the board in the needed place.
//--------------------------------------------------------------
void mapEditor::mouseButtonReleasedHandler()
{
    char icon = NOTHING_ICON;

    auto location =
        m_window.mapPixelToCoords(sf::Mouse::getPosition(m_window));

    m_menu.mouseButtonReleasedHandler(location, m_window, icon);

    handleIcon(icon);

    m_boradMap.mouseButtonReleasedHandler(location, m_window, m_icon);
}


//------------------------- loadMapFile ---------------------
// Load the map files
//-----------------------------------------------------------
void mapEditor::loadMapFile()
{
    std::ifstream boardFile;
    boardFile.open("Board.txt");

    if (!boardFile.is_open()) {
        userInputBoardSize();
    }
    else {
        loadExistedBoard(boardFile);
    }
    boardFile.close();
}


//---------------- userInputBoardSize ----------------
// Get user input for height and width of the map
//----------------------------------------------------
void mapEditor::userInputBoardSize()
{
    std::cout << INPUT_MSG;
    std::cin >> m_mapHeight;
    std::cin >> m_mapWidth;
    m_boradMap.intilizeMap(m_mapHeight, m_mapWidth);
}


//-------------------- loadExistedBoard -----------------------
//load board data from existed input board.txt file.
//-------------------------------------------------------------
void mapEditor::loadExistedBoard(std::ifstream& boardFile)
{
    std::string inputSize,inputNum;
    int i=0,j=0;

    getline(boardFile, inputSize);
    //get first num.
    while (j < inputSize.size() && inputSize.at(j) != ' ' ) {
        j++;
    }
    inputNum = inputSize.substr(i, j);
    m_mapHeight = stoi(inputNum);

    i = (++j);
    //get second num.
    if (j >= inputSize.size()) 
        m_mapWidth = m_mapHeight;
     else {
        while (j < inputSize.size())
            j++;
        inputNum = inputSize.substr(i, j);
        m_mapWidth = stoi(inputNum);
    }

    m_boradMap.intilizeMap(m_mapHeight, m_mapWidth);
    m_boradMap.setBoardData(boardFile);
}


//--------------------- saveMapFile -------------------------
// saves the map the user created
//-----------------------------------------------------------
void mapEditor::saveMapFile() {
    std::ofstream outputFile;
    std::string line;

    line += std::to_string(m_mapHeight);

    if (m_mapHeight != m_mapWidth) {
        line.append(" ");
        line += std::to_string(m_mapWidth);
    }
    line.append("\n");

    outputFile.open("Board.txt");
    outputFile << line.c_str();

    for (int i = 0; i < m_mapHeight; i++) {
        for (int j = 0; j < m_mapWidth; j++) {
            outputFile.put((m_boradMap.getCell(i, j)).getIcon());
        }
        outputFile.put('\n');
    }

    outputFile.close();
}


//---------------------- handleIcon -----------------------
// handles the icon the user pressed and acts accordingly
//---------------------------------------------------------
void mapEditor::handleIcon(const char& icon)
{
    if (icon == SAVE_ICON)
    {
        saveMapFile();
        m_icon = NOTHING_ICON;
        mapSaved = true;
    }
    else if (icon == CLEAR_ICON)
    {
        m_boradMap.intilizeMap(m_mapHeight, m_mapWidth);
        m_icon = NOTHING_ICON;
    }
    else if (icon != NOTHING_ICON)
    {
        m_icon = icon;
    }

    if (icon != SAVE_ICON) {
        mapSaved = false;
    }
}


//---------------- saveTextures ------------------
//save all textures used in map.
//------------------------------------------------
void mapEditor::saveTextures() {
    sf::Texture objectsTextures;

    objectsTextures.loadFromFile("player.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("enemy.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("coin.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("floor.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("pipe.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("ladder.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("save.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("delete.png");
    m_textures.push_back(objectsTextures);

    objectsTextures.loadFromFile("clear.png");
    m_textures.push_back(objectsTextures);
}