//----------------- include section ---------------
#include <iostream>
#include <cstdlib>
#include <SFML/Graphics.hpp>
#include "mapEditor.h"


//---------------- using section -----------------
using std::cin;
using std::endl;
using std::cout;


//---------------- main section -------------------
int main() {
	mapEditor map;
	map.displayWindow();

	return EXIT_SUCCESS;
}
