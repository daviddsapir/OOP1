
//-------------- include section ---------------
#include "BoardCell.h"
#include "Macros.h"


// c-tor
BoardCell::BoardCell(const float width, const float height,
	const int col,const int row )
	:m_width(width),m_height(height),m_col(col),
	m_row(row),m_icon(EMPTY_ICON),m_texture(NULL),
	m_color(sf::Color::Black)
{}


//---------------- setIcon -----------------
// set the icon
//------------------------------------------
void BoardCell::setIcon(const char icon) {
	if(icon != NOTHING_ICON)
		m_icon = icon;
}


//-------------- getIcon ----------------
// set the icon
//---------------------------------------
const char BoardCell::getIcon() {
	return m_icon;
}


//------------------- setCellTexture ---------------------
// sets the current wanted cells texture 
//--------------------------------------------------------
void BoardCell::setCellTexture( sf::Texture *texture) {
	m_texture = texture;
}


//---------------------- mouseHoverTableCell ----------------------
// handles the situation the the mouse is over the table cell
//-----------------------------------------------------------------
void BoardCell::mouseHoverTableCell(const sf::Vector2f& location)
{

	// get the shape and check if it contaions the curr location.
	if (getShape().getGlobalBounds().contains(location))
	{
		setOutlineColor(sf::Color::Red);
	}
	else
	{
		setOutlineColor(sf::Color::Black);
	}
}


//---------------------- setOutlineColor ------------------------
// sets the outline color of the current cell the mouse is over.
//---------------------------------------------------------------
void BoardCell::setOutlineColor(const sf::Color color)
{
	m_color = sf::Color(color);
}


//-------------------- getOutlineColor -------------------
// returns the outline color
//--------------------------------------------------------
sf::Color BoardCell::getOutlineColor() const {
	return m_color;
}


//----------------------- getShape --------------------------
// return the shape with the needed characteristics
//-----------------------------------------------------------
sf::RectangleShape BoardCell::getShape() {
	sf::RectangleShape temp_rec =
		sf::RectangleShape(sf::Vector2f(m_width, m_height));

	temp_rec.setPosition(m_col * m_width +
		(BEGIN_BOARD_POSITION_X), m_row * m_height);
	temp_rec.setOutlineThickness(BOARD_CELL_THICK);
	temp_rec.setOutlineColor(getOutlineColor());

	if (m_texture == NULL) {
		temp_rec.setFillColor(sf::Color::Transparent);
	}
	else {
		temp_rec.setFillColor(sf::Color::White);
		temp_rec.setTexture(&(*m_texture));
	}

	return temp_rec;
}


