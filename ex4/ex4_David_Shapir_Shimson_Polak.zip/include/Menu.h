#pragma once
#include "Button.h"

//--------------- include section ---------------
#include "Macros.h"
#include <SFML/Graphics.hpp>

//--------------- class section -----------------
class Menu {
public:

	// c- tor
	Menu(std::vector<sf::Texture>* textures);
	

	// Draws the menu
	void draw(sf::RenderWindow& window);
	

	// Handles the event that the mouse is over the menu
	void mouseHoverHandlerMenu(const sf::Vector2f&, sf::RenderWindow&);


	// Handles the event that the button realsed over the menu
	void mouseButtonReleasedHandler(const sf::Vector2f&,
		sf::RenderWindow&, char&);

	
	// Return button object in wanted index
	Button getButton(const int index);


	// Return the button icon in the menu
	char getButtonIcon(const sf::Vector2f&);


	// Set the player button color
	void setPlayerBtnColor(const bool getIsPlayerExist,const char icon);
private:
	
	// Draws the buttons of the board
	void drawButtons(sf::RenderWindow& window);


	// Draws the menu text
	void drawMenuText(sf::RenderWindow& window);

	// returns the next button position 
	sf::Vector2f& getNextButtonPosition(sf::Vector2f& position) const;

	// create the menu by the wanted Characteristics
	sf::RectangleShape createMenu() const;

	std::vector<Button> m_button = std::vector<Button>(BUTTON_AMOUNT);

	std::vector<sf::Texture>* m_textures;
};
//endof class menu