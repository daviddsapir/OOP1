#pragma once


//------------ include section -------------
#include <SFML/Graphics.hpp>
#include "Macros.h"
#include "menu.h"
#include "Board.h"
#include "Button.h"
#include<fstream>


//----------------- class section --------------------
class mapEditor {
public:

	// c-tor
	mapEditor();

	// Displays the window
	void displayWindow();

private:

	// Saves the textures
	void saveTextures();


	// Draws the map 
	void draw();


	// Handles the event that the mouse is over an object
	void mouseHoverHandler();


	// Dandles the event that the user realsed the 
	// mouse button.
	// (more info in definition)
	void mouseButtonReleasedHandler();


	// Loads the map files.
	void loadMapFile();


	// Set map by user input.
	void userInputBoardSize();


	// Load board data from existed input board.txt file.
	void loadExistedBoard( std::ifstream &boardFile);


	// Saves the map the user created
	void saveMapFile();


	// Displays the logo map saved
	void displayMapSavedLogo();

	// Handle the icon the user pressed
	void handleIcon(const char& icon);


	Menu m_menu;
	Board m_boradMap;
	
	std::vector<sf::Texture>m_textures;
	sf::RenderWindow m_window;

	int m_mapWidth,                 
		m_mapHeight;                    

	char m_icon = EMPTY_ICON;
	
	bool mapSaved = false;
};