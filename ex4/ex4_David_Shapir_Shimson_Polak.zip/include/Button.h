﻿#pragma once

//------------ include section -------------
#include <SFML/Graphics.hpp>
#include "Macros.h"
#include <vector>


//------------- class section ------------------
class Button {
public:

	//c-tor 
	Button(const int& = 0,const int& = 0);


	// set the position of the button
	void setPosition(const double& x, const double& y);


	// draw the button obejct
	void draw(sf::RenderWindow& window) const;


	// set the shape of the size
	void setShapeSize(const double&, const double&);


	// return the shape size
	const sf::Vector2f& getShapeSize() const;


	// reutrns if the mouse is over the button
	bool mouseHover(const sf::Vector2f&);


	// set the outline color 
	void setOutlineColor(const sf::Color&);

	
	// set the color of the button
	void setColor(const sf::Color&);


	// returns the outline color 
	sf::Color getOutlineColor() const;
	

	// sets the outline thickness
	void setOutlineThickness(const int&);


	// return the outline thickness
	int getOutlineThickness() const;


	// sets the wanted texture 
	void setTexture(sf::Texture* texture);


private:
	
	// auxillary function the create the shape with
	// wanted Characteristics
	sf::RectangleShape createShape() const;


	sf::Vector2f m_shapeSize;


	// to hold object position
	sf::Vector2f m_position;

	// to control the outline thickness
	int m_outlineThickness;


	sf::Texture* m_texture = NULL;

	sf::Color m_outLineColor = sf::Color::Black;

	sf::Color m_color = sf::Color::White;
};
