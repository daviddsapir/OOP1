#pragma once 
#include <SFML/Graphics.hpp>

//------------------ window consts -------------------------
const double
WINDOW_HIGHT = 900,
WINDOW_WIDTH = 1400,
MENU_WIDTH = WINDOW_WIDTH * 0.2;
const std::string INPUT_MSG = "Enter map size : \n";

//------------------ button consts----------------------------
const double
BUTTON_MENU_POSITION_X = MENU_WIDTH * 0.1,

BUTTON_AMOUNT = 9,
BUTTON_WIDTH_SIZE = 0.15 * WINDOW_WIDTH,
BUTTON_HIGHT_SIZE = 0.08 * WINDOW_HIGHT,

BUTTON_MENU_SPACES = BUTTON_HIGHT_SIZE / 1.6,

BEGIN_BUTTON_POSITION_X = MENU_WIDTH * 0.1,
BEGIN_BUTTON_POSITION_Y = 0.1 * WINDOW_HIGHT,

DEFAULT_BUTTON_THICKNESS = 5,
BUTTON_MOUSE_HOVER_THICKNESS = 8;

//------------------ board consts ---------------------------
const double
BOARD_WIDTH_SIZE = 0.8 * WINDOW_WIDTH,
BOARD_HEIGHT_SIZE = WINDOW_HIGHT,
BEGIN_BOARD_POSITION_X = 0.2 * WINDOW_WIDTH,
BEGIN_BOARD_POSITION_Y = 0,
BOARD_CELL_THICK = 2;

const int DEFULT_SIZE = 10;

//------------------ icons consts----------------------------
const char
PLAYER_ICON = '@',
BLOCK_ICON = '#',
COIN_ICON = '*',
LADDER_ICON = 'H',
ENEMY_ICON = '%',
PIPE_ICON = '-',
EMPTY_ICON = ' ',
SAVE_ICON = 's',
CLEAR_ICON = 'c',
NOTHING_ICON = 'n';

//---------------------vector textures indexes consts ---------------------------
const int
NUM_TEXTURES = 10,
PLAYER = 0,
ENEMY = 1,
COIN = 2,
BLOCK = 3,
PIPE = 4,
LADDER = 5,
SAVE = 6,
DELETE = 7,
CLEAR = 8;


//--------------------- Color consts ---------------------------
const sf::Color GREY = sf::Color(128, 128, 128);


//--------------------- Font consts ---------------------------
const double
SAVE_FONT_POSITION_X = WINDOW_WIDTH / 2 - 100,
SAVE_FONT_POSITION_Y = 15,
SAVE_FONT_SIZE = 45,
SAVE_FONT_THICK = 10,
SAVE_FONT_SPACE = 4,
SAVE_FONT_STYLE = 3;

const double
MENU_FONT_POSITION_X = 45,
MENU_FONT_POSITION_Y = 15,
MENU_FONT_SIZE = 45,
MENU_FONT_THICK = 3,
MENU_FONT_SPACE = 4,
MENU_FONT_STYLE = 3;