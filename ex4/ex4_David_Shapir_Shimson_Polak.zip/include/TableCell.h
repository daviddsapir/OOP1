#pragma once
#include <SFML/Graphics.hpp>
#include <string>

class TableCell
{
public:

	// c-tor
	TableCell() = default;


	// c-tor
	TableCell
	(const float width, const float height,const int col, const int row);


	// Sets the icon
	void setIcon(const char icon);


	// Sets the current wanted cells texture 
	void setCellTexture( sf::Texture* texture);


	// Handles the situation the the mouse is over the table cell
	void mouseHoverTableCell(const sf::Vector2f&);


	// Sets the outline color of the current cell the mouse is over
	void setOutlineColor(const sf::Color color);


	// Returns the outline color
	sf::Color getOutlineColor() const;


	// Return the shape
	sf::RectangleShape getShape();


	// Returns the icon
	const char getIcon();

private:

	char m_icon;         // to hold the icon

	int m_row,           // to know location
		m_col; 

	float m_height,      // to hold the hight
		m_width;		 // and the width of the cell object

	// to hold the color
	sf::Color m_color;   

	std::string m_textureFileName = " ";
	
	sf::Texture* m_texture = NULL;
};