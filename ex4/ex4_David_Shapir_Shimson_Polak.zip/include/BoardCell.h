#pragma once
#include <SFML/Graphics.hpp>
#include <string>

class BoardCell
{
public:

	// c-tor
	BoardCell() {}      

	// c-tor
	BoardCell
	(const float width, const float height,const int col, const int row);


	// set the icon
	void setIcon(const char icon);


	// set the current wanted cells texture 
	void setCellTexture( sf::Texture* texture);


	// handle the event that the mouse is over the table cell
	void mouseHoverTableCell(const sf::Vector2f&);


	// set the outline color of the current cell the mouse is over
	void setOutlineColor(const sf::Color color);


	// return the outline color
	sf::Color getOutlineColor() const;


	// return the shape
	sf::RectangleShape getShape();


	// returns the icon
	const char getIcon();

private:

	char m_icon;         // to hold the icon

	int m_row,           // to know location
		m_col; 

	float m_height,      // to hold the hight
		m_width;		 // and the width of the cell object

	// to hold the color
	sf::Color m_color;   

	std::string m_textureFileName = " ";
	
	sf::Texture* m_texture = NULL;
};