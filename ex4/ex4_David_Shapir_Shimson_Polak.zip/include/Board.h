#pragma once

//----------------- include section -----------------
#include <vector>
#include <BoardCell.h>
#include <SFML/Graphics.hpp>

using std::vector;


//------------------ class section -------------------
class Board
{
public:

	// c-tor
	Board(const int height,const int width,
		std::vector<sf::Texture>* textures);


	// c-tor
	Board(std::vector<sf::Texture>* textures);
	

	// set the map height and width
	void intilizeMap(const int height, const int width);

	
	// sets the data of the map form an external file
	void setBoardData(std::ifstream& file);


	//get member is playerExist;
	const bool getIsPlayerExist();
	

	// runs over the cells of the board and sets the object textures
	// (more info in function difinition)
	void setCellTextureByIcon(const char icon, const int row, const int col);


	// draw the board
	// (more info in function difinition)
	void draw(sf::RenderWindow &window);


	// handle the situation that the mouse is over the board.
	void mouseHoverBoardHandler(const sf::Vector2f&, sf::RenderWindow&);


	// returns the width of the board.
	const int getWidth();		
	

	// returns the width of the board.
	const int getHeight();


	// returns the current cell in the board 
	BoardCell getCell(const int row, const int col);


	// handles mouse button realse
	void mouseButtonReleasedHandler
	(const sf::Vector2f& location, sf::RenderWindow& window, const char icon);

private:

	//sf::RectangleShape m_mapBackground;
	vector <vector<BoardCell> > m_table;

	// build the BackgroundShape
	// (more info in function difinition)
	sf::RectangleShape getBackgroundShape();


	// auxillary function that sets the board
	void setBoard();

	//auxillary function that sets single cell in board icon.
	void setBoardCellIcon(const char icon, const int row, const int col);

	sf::Texture m_bacgroundTexture;


	// to hold the hight and the width
	// of the board the user wants
	int m_height, m_width;

	// to knwo if the player exist
	bool playerExist = false;

	std::vector<sf::Texture>* m_textures;
};


