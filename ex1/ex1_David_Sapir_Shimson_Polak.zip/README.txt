=====================================================================

OOP, ex1
========

by: David Sapir & Shimson Polak 
id: David - 208917351
    Shimson - 315605642 


=====================================================================

                       Description
                     =================				 
Our assignment is to build the following shapes:
1. Rectangle
2. Isosceles triangle
3. Equilateral triangle
4. Window
Those 4 objects display to the terminal (drew) by the support of
the classes we have been given.

Note that: Every class represent a different shape.

=====================================================================

                         Included files
                        =================	
There are 4 object files built by us:
1)Rectangle.cpp - This class was build by using:
  1. bottomLeft vetex and TopRight Vertex.
  2. By getting two points.
  3. By getting Center, width and height.
2)Isosceles triangle - Build by the following ways:
  1. Getting a 3 vertices.
  2. Getting 2 vertices + hight.
3)EquilateralTriangle.cpp - By getting 3 vertices, and using the 
  the support of Isosceles triangle calss.
4)Window.cpp - build with two rectangles.using rectangle class.

Also every '.cpp' file has a header file.
4 source + 4 header = 8 files in total.
=====================================================================
                           Data Structure
                           ==============
=====================================================================

                           Algorithms worth mention:
                         =============================
Rectangle that is blocking the triangle is calculate by:
minimum X and Y of the vertexes of the triangle will be the
bottomleft of the rectangle and maxmum X and Y of the vertexes
of the triangle will be the topright of the rectangle.
The same thing is done for an opisite traingle.

=====================================================================
 
                                 Known bugs
                               ===============

=====================================================================


Comments
=====================================================================





