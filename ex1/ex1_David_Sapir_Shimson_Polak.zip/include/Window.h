#pragma once
#include"Rectangle.h"
#include"Utilities.h"

class Window {
public:
	//-------------- Constructors Section --------------------------------------//

	//Window c-tor get outer and inner rectangle.
	Window(const Rectangle& outer, const Rectangle& inner);

	//Window c-tor get the outer rectangle and 
	//the vertical and horizontal thickness
	Window(const Rectangle& outer, double verticalThickness,
		double HorizontalThickness);

	//--------------------------------------------------------------------//
	//Get Rectangle bottom left vertex.
	Vertex getBottomLeft()const;

	//Get Rectangle bottom right vertex.
	Vertex getTopRight()const;

	//Draw Window on board.
	void draw(Board& board) const;

	//Scale function by factor.
	bool scale(double factor);

	//Window get data function.
	Rectangle getBoundingRectangle() const;

	//Get the Rectangle center.
	Vertex getCenter() const;

	//Get the vertical thickness.
	double getVerticalThickness()const;

	//Get the horizontal thickness.
	double getHorizontalThickness()const;

	//Get windows area size.
	double getArea() const;

	//Get windows perimeter size.
	double getPerimeter() const;

private:
	

	//Data members.
	Rectangle m_inner, m_outer;

	Vertex m_center, m_BL, m_TR;

	double m_verticalThick, m_horizontalThick,m_area,m_perim;

	//Check if given vertexes are valid
	bool isValidRecsVert();

	//Check if vertical and horizontal thickness are valid.
	bool isValidThickness();

	//Set defualt values.
	void setDefault();

	//Set vertical and horizontal thickness.
	void setVertHoriz();

	//Set inner rectangle values.
	void setInnerRec();

	//Set window members:area , perim , center.
	void setWinData();
	
	//Set window area.
	void setArea();

	//Set window perimeter.
	void setPerim();

	//Set window center.
	void setCenter();
};
