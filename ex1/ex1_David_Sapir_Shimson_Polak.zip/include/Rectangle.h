#pragma once
#include "Vertex.h"
#include "Board.h"

class Rectangle {
public:

	//----------------------- Constructors Section ------------------------//
	//Defult c-tor.
	Rectangle();

	//Rectangle c-tor get two vertexes,bottom left and top right.
	Rectangle(const Vertex& bottomLeft, const Vertex& topRight);

	//Rectangle c-tor get array of 2d Vertex 0 - bottom left,1- top right.
	Rectangle(const Vertex vertices[2]);

	//Rectangle c-tor get 2 coordinates of x y.
	Rectangle(double x0, double y0, double x1, double y1);

	//Rectangle c-tor get center , width , height.
	Rectangle(const Vertex& center, double width, double height);
	//--------------------------------------------------------------------//

	//Member functions
	//Get Rectangle bottom left vertex.
	Vertex getBottomLeft() const;

	//Get Rectangle bottom right vertex.
	Vertex getTopRight() const;

	//Get Rectangle width vertex.
	double getWidth() const;

	//Get Rectangle height vertex.
	double getHeight() const;

	//Draw Rectangle on board.
	void draw(Board& board) const;

	//Get the Rectangle bounding.
	Rectangle getBoundingRectangle() const;

	//Get the Rectangle area.
	double getArea() const;

	//Get the Rectangle area.
	double getPerimeter() const;

	//Get the Rectangle center.
	Vertex getCenter() const;

	//Scale function by factor.
	bool scale(double factor);


private:
	//Data members
	Vertex m_pointBl, m_pointTr, m_pointBr, m_pointTl, m_center;

	double m_width,
		m_height;

	// Auxillary functions

	//Set the bottom left and top right vertex .
	//Params: point vertex to set, center vertex, height and width.
	void setPointByCenter(Vertex&, const Vertex&, double, double);

	//Set the rectangle height and width.
	void setHeightAndWidth();

	//Set rectangle defualt values.
	void setDeafualt();

	//Set the center vertex.
	void setCenter();

	//Set bootom right and top left vertices.
	void setBrTlVertex();

	//Check if given vertices are valid.
	bool isValidVertexes();

	//Scale the Rectangle vertices.
	void scaleByDistXY(const double temp_x, const double temp_y);

	

};