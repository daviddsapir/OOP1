#include "Vertex.h"
#include "Utilities.h"
#include <cmath>
#include "Board.h"
#include "Rectangle.h"

#pragma once

class IsoscelesTriangle {

public:
 
	/******************** Constructors Section *************************
	IsoscelesTriangle c-tor gets an array of vertices and
	inserts their (only if they are valild)
	values into the data members.
	********************************************************************/
	IsoscelesTriangle(const Vertex vertices[3]);

	/*
	IsoscelesTriangle c-tor get 2 triangle base vertexes,
	height of the triangle.
	*/
	IsoscelesTriangle(const Vertex& v0, const Vertex& v1,
		double height);

	//-----------------------------------------------------------//

	// This function return the wanted vertex
	Vertex getVertex(int index)const;

	// This function returns the base length of the triangle.
	double getBaseLength()const;

	// This function returns the leg length of the triangle.
	double getLegLength()const;

	// This function returns the height of the triangle.
	double getHeight()const;

	// This function draws the traingle.
	void draw(Board& board) const;

	// This function return a pointer to the Rectangle
	// that Bounds the triangle.
	Rectangle getBoundingRectangle() const;

	// This function returns the area of the triangle. 
	double getArea() const;

	// This function returns the perimeter of the triangle.
	double getPerimeter() const;

	// This function return the center vertex
	Vertex getCenter() const;

	// This function checks if the scale of the triangle woreked
	// If the scale wored, the data members will change.
	bool scale(double factor);

	


private:
	
	// sets the deafualt values.
	void setDeafualt();

	// calls the functions listed below to calculate the 
	// triangle characteristics.
	void calcCharacteristics();

	// calculates the mid point of the triangle.
	Vertex calcMidPoint(const Vertex&, const  Vertex&, double);

	// calculates the leg length of the triangle.
	void calcLegLength();

	// calculates the hight of the triangle.
	void calcHight();

	// calculates the base length of the triangle.
	void calcBaseLength();

	// calculates the center of the triangle &
	// saves the vertex into a data member called m_center. 
	Vertex calcCenter();

	// calculates the perimeter of the triangle.
	void calcPerimeter();

	// calculates the area of the triangle.
	void calcArea();

	// the function checks if the user entered a valid vertices
	// for the first c-tor. 
	bool legalVertices1(const Vertex v[3]);

	// the function checks if the user entered a valid vertices
	// for the second c-tor.
	bool legalVertices2(const Vertex&, const Vertex&);

	// This function scales vertices values by scale distance.
	void scaleUpward(Vertex v[3], double factor);

	// This function scales vertices values by scale distance.
	void scaleDownward(Vertex v[3], double factor);


	// Data members
	Vertex m_vertices[3],
		m_center;

	double m_baseLength,
		m_hight,
		m_legLength,
		m_area,
		m_perimeter;
};
