#pragma once

const auto MAX_COL = 70;
const auto MAX_ROW = 50;
