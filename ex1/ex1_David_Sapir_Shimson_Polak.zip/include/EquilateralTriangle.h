#include "Vertex.h"
#include "Rectangle.h"
#include "IsoscelesTriangle.h"

#pragma once

class EquilateralTriangle {

public:
	//-------------- Constructors Section --------------------------------------//
	//EquilateralTriangle c-tor get array of 3 vertexes.
	EquilateralTriangle(const Vertex vertices[3]);

	//----------------------------------------------------------------------//

	// This function return the wanted vertex
	Vertex getVertex(int) const;

	// This function return the the triangle leg length.
	double getLength() const;

	// This function draws the traingle.
	void draw(Board& board) const;

	// This function return a pointer to the Rectangle
	// that Bounds the triangle.
	Rectangle getBoundingRectangle() const;

	// This function returns the area of the triangle. 
	double getArea() const;

	// This function returns the perimeter of the triangle.
	double getPerimeter() const;

	// This function return the center vertex
	Vertex getCenter() const;

	// This function checks if the scale of the triangle woreked
	// If the scale wored, the data members will change.
	bool scale(double factor);

private:

	// we set all values to default
	void setDeafualt();

	// data memebers
	IsoscelesTriangle m_triangle;
};