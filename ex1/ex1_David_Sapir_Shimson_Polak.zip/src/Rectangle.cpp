#include "..\include\Rectangle.h"
#include "macros.h"
#include "Utilities.h"


//----------------------- Constructors Section ---------------------------//
//Defult c-tor.
Rectangle::Rectangle()
{
	setDeafualt();
}

//Rectangle c-tor get two vertices,bottom left and top right.
Rectangle::Rectangle(const Vertex& bottomLeft, const Vertex& topRight)
	:Rectangle(bottomLeft.m_col, bottomLeft.m_row,
		topRight.m_col, topRight.m_row) {}

//Rectangle c-tor get array of 2d Vertex 0 - bottom left,1- top right.
Rectangle::Rectangle(const Vertex vertices[2])
	: Rectangle(vertices[0], vertices[1]){}

//Rectangle c-tor get 2 coordinates of x y.
Rectangle::Rectangle(double x0, double y0, double x1, double y1) :
	m_pointBl(x0, y0), m_pointTr(x1, y1)
{
	if (isValidVertexes()) {

		setBrTlVertex();

		setCenter();

		setHeightAndWidth();

	}
	else 
		setDeafualt();
}

//Rectangle c-tor get center , width , height.
Rectangle::Rectangle(const Vertex& center, double width, double height) :
	m_center(center), m_width(width), m_height(height)
{

	setPointByCenter(m_pointBl, center, (-1) * width, (-1) * height);

	setPointByCenter(m_pointTr, center, width, height);

	if (isValidVertexes()) {

		setBrTlVertex();

	}
	else 
		setDeafualt();
}

//--------------------------------------------------------------------//

//Get vertex bottom left.
Vertex Rectangle::getBottomLeft() const
{
	return m_pointBl;
}

//--------------------------------------------------------------------//
//Get vertex top left.
Vertex Rectangle::getTopRight() const
{
	return m_pointTr;
}

//--------------------------------------------------------------------//
//Get the rectangle width.
double Rectangle::getWidth() const
{
	return m_width;
}

//--------------------------------------------------------------------//
//Get the rectangle height.
double Rectangle::getHeight() const
{
	return m_height;
}

//--------------------------------------------------------------------//
//Draw rectangle on board.
void Rectangle::draw(Board& board) const
{
	board.drawLine(m_pointBl, m_pointBr);
	board.drawLine(m_pointBl, m_pointTl);
	board.drawLine(m_pointBr, m_pointTr);
	board.drawLine(m_pointTl, m_pointTr);
}

//--------------------------------------------------------------------//
//Get the rectangle bounding.
Rectangle Rectangle::getBoundingRectangle() const
{
	return Rectangle(m_pointBl.m_col, m_pointBl.m_row
		, m_pointTr.m_col, m_pointTr.m_row);
}

//--------------------------------------------------------------------//
//Get the rectangle area.
double Rectangle::getArea() const
{
	return (m_width * m_height);
}

//--------------------------------------------------------------------//
//Get the rectangle perimeter.
double Rectangle::getPerimeter() const
{
	return (2 * (m_width + m_height));
}

//--------------------------------------------------------------------//
//Get The center.
Vertex Rectangle::getCenter() const
{
	return m_center;
}

//--------------------------------------------------------------------//
//Scale the rectangle size by factor.
bool Rectangle::scale(double factor)
{
	double distance_x = (m_center.m_col - m_pointBl.m_col)
		* factor - (m_center.m_col - m_pointBl.m_col),
		distance_y = (m_center.m_row - m_pointBl.m_row)
		* factor - (m_center.m_col - m_pointBl.m_col);

	if (m_pointBl.m_col - distance_x >= 0 &&
		m_pointBl.m_row - distance_y >= 0 &&
		m_pointTr.m_col + distance_x <= MAX_COL &&
		m_pointTr.m_row + distance_y <= MAX_ROW) {

		scaleByDistXY(distance_x, distance_y);

		setBrTlVertex();

		setCenter();

		setHeightAndWidth();

		return true;
	}
	
	return false;

	
}

//--------------------------------------------------------------------//
//Set default values.
void Rectangle::setDeafualt()
{

	m_pointBl = Vertex(20,10);

	m_pointTr = Vertex(30,20);

	m_center = Vertex(25,15);

	m_pointBr = Vertex(30,10);

	m_pointTl = Vertex(20,20);

	m_height = 10;

	m_width = 10;

	
	
}

//--------------------------------------------------------------------//
//Set the bottom left and top right vertex .
//Params: point vertex to set, center vertex, height and width.
void Rectangle::setPointByCenter(Vertex& point, const Vertex& center, 
	double width, double height)
{
	point.m_col = center.m_col + (width / 2);
	point.m_row = center.m_row + (height / 2);
}

//--------------------------------------------------------------------//
//Calculate triangle height and width.
void Rectangle::setHeightAndWidth()
{
	m_height = (m_pointTr.m_row) - (m_pointBl.m_row);
	m_width = (m_pointTr.m_col) - (m_pointBl.m_col);
}

//--------------------------------------------------------------------//
//Calculate the center of the rectangle.
void Rectangle::setCenter()
{
	m_center.m_col = 
		(m_pointTr.m_col + m_pointBl.m_col ) / 2;
	m_center.m_row =
		(m_pointTr.m_row + m_pointBl.m_row ) / 2;
}

//--------------------------------------------------------------------//
//Set vertices bottom left and top left.
void Rectangle::setBrTlVertex()
{
	m_pointBr.m_col = m_pointTr.m_col;
	m_pointBr.m_row = m_pointBl.m_row;

	m_pointTl.m_col = m_pointBl.m_col;
	m_pointTl.m_row = m_pointTr.m_row;
}

//--------------------------------------------------------------------//
//Check is existed vertices are valid
bool Rectangle::isValidVertexes()
{
	return (m_pointBl.isValid() && m_pointTr.isValid() &&
		m_pointTr.isHigherThan(m_pointBl) &&
		m_pointTr.isToTheRightOf(m_pointBl));
}

//--------------------------------------------------------------------//
//Scale bottom left and top right by distance x y from center.
void Rectangle::scaleByDistXY(const double dist_x,const double dist_y)
{
	m_pointBl.m_col -= dist_x;
	m_pointBl.m_row -=  dist_y;

	m_pointTr.m_col +=  dist_x;
	m_pointTr.m_row +=  dist_y;
}
//--------------------------------------------------------------------//