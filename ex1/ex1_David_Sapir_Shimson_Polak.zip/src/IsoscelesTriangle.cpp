#include "IsoscelesTriangle.h"

//-------------------- Constructors Section -------------------//
/*
IsoscelesTriangle c-tor gets an array of vertices and
inserts their (only if they are valild) 
values into the data members.
*/
IsoscelesTriangle::IsoscelesTriangle(const Vertex vertices[3])
{
	if (legalVertices1(vertices)) 
		for (int i = 0; i < 3; i++)
			m_vertices[i] = vertices[i];
	else setDeafualt();
	
	calcCharacteristics();
}


/*
 IsoscelesTriangle c-tor get 2 triangle base vertexes,
 height of the triangle.
*/
IsoscelesTriangle::IsoscelesTriangle(const Vertex& v0,
	const Vertex& v1, double height)
{
	if (legalVertices2(v0, v1)) 
		m_vertices[2] = calcMidPoint(v0, v1, height);
	else setDeafualt();

	calcCharacteristics();
}

//------------------------------------------------------------------------//

//Check if the given vertexes in the vertex array are valid.
bool IsoscelesTriangle::legalVertices1(const Vertex v[3])
{
	return (v[0].isValid() && v[1].isValid() && v[2].isValid() &&
		v[1].isToTheRightOf(v[0]) && sameRow(v[0], v[1]) &&
		distance(v[0], v[2]) == distance(v[1], v[2]));
}


//----------------------------------------------------------------------//
//Check if the given 2 vertexes are valid. 
bool IsoscelesTriangle::legalVertices2(const Vertex& v0, const Vertex& v1)
{
	return (v0.isValid() && v1.isValid() &&
		v1.isToTheRightOf(v0) && sameRow(v0, v1));
}


//----------------------------------------------------------------------//
/*Get the vertex by'index' from member m_vertices by the index values:
* 0-return the left base vertex.
* 1-return the righ side base vertex.
* 2-return the middle triangle vertex.
* */
Vertex IsoscelesTriangle::getVertex(int index) const
{
	return m_vertices[index];
}


//----------------------------------------------------------------------//
//Get the triangle base length.
double IsoscelesTriangle::getBaseLength() const
{
	return m_baseLength;
}


//----------------------------------------------------------------------//
//Get triangle leg length.
double IsoscelesTriangle::getLegLength() const
{
	return m_legLength;
}


//----------------------------------------------------------------------//
//Get the height of the triangle.
double IsoscelesTriangle::getHeight() const
{
	return m_hight;
}


//----------------------------------------------------------------------//
//Draw the triangle shape on given 'board'.
void IsoscelesTriangle::draw(Board& board) const
{
	board.drawLine(m_vertices[0], m_vertices[1]);
	board.drawLine(m_vertices[0], m_vertices[2]);
	board.drawLine(m_vertices[1], m_vertices[2]);
}


//----------------------------------------------------------------------//
//Get the minimal bounding Rectangle of the triangle shape.
Rectangle IsoscelesTriangle::getBoundingRectangle() const
{
	Vertex BL, TR;

	if (m_vertices[0].m_row < m_vertices[2].m_row) {
		BL = Vertex(m_vertices[0].m_col,m_vertices[0].m_row);
		TR = Vertex(m_vertices[1].m_col, m_vertices[2].m_row);
	}
	else {
		BL = Vertex(m_vertices[0].m_col, m_vertices[2].m_row);
		TR = Vertex(m_vertices[1].m_col, m_vertices[1].m_row);
	}

	return Rectangle(BL, TR);
}


//----------------------------------------------------------------------//
//Get the triangle area.
double IsoscelesTriangle::getArea() const
{
	return m_area;
}


//----------------------------------------------------------------------//
//Get the triangle perimeter.
double IsoscelesTriangle::getPerimeter() const
{
	return m_perimeter;
}


//----------------------------------------------------------------------//
//Get the triangle Center.
Vertex IsoscelesTriangle::getCenter() const
{
	return m_center;
}


//----------------------------------------------------------------------//
//Scale the triangle size by given 'factor'.
bool IsoscelesTriangle::scale(double factor)
{
	Vertex v[3];

	for (int i = 0; i < 3; i++) {
		v[i] = m_vertices[i];
	}

	if (v[0].m_row < v[2].m_row) 
		scaleUpward(v,factor);
	else
		scaleDownward(v, factor);

	if (v[0].isValid() && v[1].isValid() && v[2].isValid()) {
		for (int i = 0; i < 3; i++)
			m_vertices[i] = v[i];

		calcCharacteristics();
		return true;
	}

	return false;
}


//----------------------------------------------------------------------//
/*
* Scale triangle accordingly if the middle vertex above base.
* Params: Vertexes array , size to scale.
*/
void IsoscelesTriangle::scaleUpward(Vertex v[3],double factor)
{
	double scale_dist_x = (m_center.m_col - m_vertices[0].m_col) * factor - 
		(m_center.m_col - m_vertices[0].m_col),
	 scale_dist_y = (m_center.m_row - m_vertices[0].m_row) * factor - 
		(m_center.m_row - m_vertices[0].m_row);

	v[0].m_col -= scale_dist_x;
	v[0].m_row -= scale_dist_y;

	v[1].m_col += scale_dist_x;
	v[1].m_row -= scale_dist_y;

	v[2].m_row += scale_dist_y;
}


//----------------------------------------------------------------------//
/*
* Scale triangle accordingly if the middle vertex above base.
* Params: Vertexes array, size to scale.
*/
void IsoscelesTriangle::scaleDownward(Vertex v[3], double factor)
{
	double scale_dist_x = (m_center.m_col - m_vertices[0].m_col) * factor - 
		(m_center.m_col - m_vertices[0].m_col),
		scale_dist_y = (m_vertices[0].m_row - m_center.m_row) * factor -
		(m_vertices[0].m_row - m_center.m_row);

	v[0].m_col -= scale_dist_x;
	v[0].m_row += scale_dist_y;

	v[1].m_col += scale_dist_x;
	v[1].m_row += scale_dist_y;

	v[2].m_row -= scale_dist_y;
}


//----------------------------------------------------------------------//
//Set triangle vertexes defualt values. 
void IsoscelesTriangle::setDeafualt() {
	m_vertices[0].m_row = 20;
	m_vertices[0].m_col = 20;

	m_vertices[1].m_col = 30;
	m_vertices[1].m_row = 20;

	m_vertices[2].m_row = 20 + sqrt(75);
	m_vertices[2].m_col = 25;
}


//----------------------------------------------------------------------//
/*Calculate triangle the middle vertex by 2 vertexes and height.
* Params:triangle base left vertex,triangle base right vertex,triangle height.
* */
Vertex IsoscelesTriangle::calcMidPoint(const Vertex& v0,
	const  Vertex& v1, double height)
{
	Vertex midPoint;

	midPoint.m_col = (v0.m_col + v1.m_col) / 2;
	midPoint.m_row = (v0.m_row + height);

	return midPoint;
}


//----------------------------------------------------------------------//
//Calculate some triangle members.
void IsoscelesTriangle::calcCharacteristics()
{
	calcBaseLength();
	calcLegLength();
	calcHight();
	calcPerimeter();
	calcArea();
	m_center = calcCenter();
}


//----------------------------------------------------------------------//
//Calculate triangle leg length.
void IsoscelesTriangle::calcLegLength()
{
	m_legLength = distance(m_vertices[0], m_vertices[2]);
}


//----------------------------------------------------------------------//
//Calculate triangle height length.
void IsoscelesTriangle::calcHight()
{
	m_hight = m_vertices[2].m_row - m_vertices[0].m_row;

	m_hight = (m_hight > 0) ? m_hight : (-1) * m_hight;
}


//----------------------------------------------------------------------//
//Calculate triangle base length.
void IsoscelesTriangle::calcBaseLength()
{
	m_baseLength = distance(m_vertices[0], m_vertices[1]);
}


//----------------------------------------------------------------------//
//Calculate triangle center vertex.
Vertex IsoscelesTriangle::calcCenter()
{
	Vertex c;
	double colAvg = 0, rowAvg = 0;

	for (int i = 0; i < 3; i++) {
		colAvg += m_vertices[i].m_col;
	}

	for (int i = 0; i < 3; i++) {
		rowAvg += m_vertices[i].m_row;
	}

	c.m_col = colAvg / 3;
	c.m_row = rowAvg / 3;

	return c;
}


//----------------------------------------------------------------------//
//Calculate triangle perimeter.
void IsoscelesTriangle::calcPerimeter()
{
	m_perimeter = m_baseLength + (m_legLength * 2);
}


//----------------------------------------------------------------------//
//Calculate triangle area.
void IsoscelesTriangle::calcArea()
{
	m_area = (m_baseLength * m_hight) / 2;
}

