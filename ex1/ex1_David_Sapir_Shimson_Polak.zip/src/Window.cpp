#include "Window.h"
#include"Utilities.h"
#include "Board.h"

//-------------------- Constructors Section ---------------------------//
//Window c-tor get outer and inner rectangle.
Window::Window(const Rectangle& outer, const Rectangle& inner) 
	:m_inner(inner),m_outer(outer)
{
	if (!(sameCol(outer.getCenter(), inner.getCenter()) && 
		sameRow(outer.getCenter(), inner.getCenter()) &&
		isValidRecsVert())){

		setDefault();
	}

	setVertHoriz();
	setWinData();
}

//Window c-tor get the outer rectangle and 
//the vertical and horizontal thickness
Window::Window(const Rectangle& outer,
	double verticalThickness, double horizontalThickness):
	m_horizontalThick(horizontalThickness),
	m_verticalThick(verticalThickness),
	m_outer(outer),m_inner(outer){

	if (isValidThickness())
		setInnerRec();
	else {
		setDefault();
	}

	setWinData();
}

//----------------------------------------------------------------//
//Get window vertex bottom left.
Vertex Window::getBottomLeft() const
{
	return m_outer.getBottomLeft();
}

//--------------------------------------------------------------//
//Get window vertex top left.
Vertex Window::getTopRight() const
{
	return m_outer.getTopRight();
}

//--------------------------------------------------------------//
//Get window vertical thickness top left.
double Window::getVerticalThickness() const
{
	return m_verticalThick;
}

//-------------------------------------------------------------//
//Get the horizontal thickness.
double Window::getHorizontalThickness() const
{
	return m_horizontalThick;
}

//------------------------------------------------------------//
//Draw Window on board.
void Window::draw(Board& board) const
{
	m_inner.draw(board);

	m_outer.draw(board);
}

//-----------------------------------------------------------//
//Scale function by factor.
bool Window::scale(double factor)
{

	if (m_outer.scale(factor) && m_inner.scale(factor)) {

		setVertHoriz();
		setWinData();

		return true;
	}

	return false;
}


//-------------------------------------------------------------//
//Window get data function.
Rectangle Window::getBoundingRectangle() const
{
	return m_outer;
}


//-------------------------------------------------------------//
//Get windows area size.
double Window::getArea() const
{
	return m_area;
}


//-------------------------------------------------------------//
//Get windows perimeter size.
double Window::getPerimeter() const
{
	return m_perim;
}


//----------------------------------------------------------------------//
//Get window center.
Vertex Window::getCenter()const 
{
	return m_center;
}


//----------------------------------------------------------------------//
//Check if given vertices of the rectanlges are are valid
bool Window::isValidRecsVert() {
	Vertex outBL = m_outer.getBottomLeft(), outTR = m_outer.getTopRight(),
		inBL = m_inner.getBottomLeft(), inTR = m_outer.getTopRight();

	return (outBL.m_col <= inBL.m_col && outBL.m_row <= inBL.m_row &&
		outTR.m_col >= inTR.m_col&& outTR.m_row >= inTR.m_row);
}


//----------------------------------------------------------------------//
//Check if vertical and horizontal thickness are valid.
bool Window::isValidThickness()
{
	return m_verticalThick <= (m_outer.getHeight() / 2) &&
		m_horizontalThick <= (m_outer.getWidth() / 2);
}


//----------------------------------------------------------------------//
//Set inner rectangle values.
void Window::setInnerRec()
{
	Vertex BL = m_outer.getBottomLeft(),TR=m_outer.getTopRight()
	,inBL(BL.m_col + m_horizontalThick,BL.m_row + m_verticalThick),
		inTR(TR.m_col - m_horizontalThick,TR.m_row - m_verticalThick);

	m_outer = Rectangle(inBL, inTR);

}


//----------------------------------------------------------------------//
//Set window members:area , perim , center.
void Window::setWinData() {
	setArea();
	setPerim();
	setCenter();
}


//----------------------------------------------------------------------//
//Set defualt values.
void Window::setDefault()
{	
	Rectangle defult_rectangle;

	m_inner = defult_rectangle;
	m_outer = defult_rectangle;

	m_verticalThick = 0;
	m_horizontalThick = 0;
}


//----------------------------------------------------------------------//
//Set vertical and horizontal thickness .
void Window::setVertHoriz()
{
	m_horizontalThick = m_outer.getHeight() - m_inner.getHeight();
	m_verticalThick = m_outer.getWidth() - m_inner.getWidth();
}


//----------------------------------------------------------------------//
//Set window area.
void Window::setArea()
{
	m_area = m_outer.getArea()
		- m_inner.getArea();
}


//----------------------------------------------------------------------//
//Set window perimeter.
void Window::setPerim()
{
	m_perim = m_inner.getPerimeter() +
		m_outer.getPerimeter();
}


//----------------------------------------------------------------------//
//Set window center.
void Window::setCenter()
{
	m_center = m_inner.getCenter();
}

//----------------------------------------------------------------------//
