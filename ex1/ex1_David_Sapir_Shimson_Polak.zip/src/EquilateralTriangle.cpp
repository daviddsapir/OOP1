#include "EquilateralTriangle.h"


//---------------------- Constructors Section ---------------------------//
//EquilateralTriangle c-tor get array of 3 vertexes.
EquilateralTriangle::EquilateralTriangle(const Vertex vertices[3])
	: m_triangle(vertices)
{
	if (m_triangle.getBaseLength() != m_triangle.getLegLength()) {
		setDeafualt();
	}
}

//----------------------------------------------------------------------//
/*Get the vertex by'index' from member m_vertices by the index values:
* 0-return the left base vertex.
* 1-return the righ side base vertex.
* 2-return the middle triangle vertex.
* */
Vertex EquilateralTriangle::getVertex(int index) const
{
	return m_triangle.getVertex(index);
}

//----------------------------------------------------------------------//
// This function return the the triangle leg length.
double EquilateralTriangle::getLength() const
{
	return m_triangle.getLegLength();
}

//----------------------------------------------------------------------//
// This function draws the traingle.
void EquilateralTriangle::draw(Board& board) const
{
	m_triangle.draw(board);
}

//----------------------------------------------------------------------//
// This function return a pointer to the Rectangle
// that Bounds the triangle.
Rectangle EquilateralTriangle::getBoundingRectangle() const
{
	return m_triangle.getBoundingRectangle();
}

//----------------------------------------------------------------------//
// This function returns the area of the triangle. 
double EquilateralTriangle::getArea() const
{
	return m_triangle.getArea();
}

//----------------------------------------------------------------------//
// This function returns the perimeter of the triangle.
double EquilateralTriangle::getPerimeter() const
{
	return m_triangle.getPerimeter();
}

//----------------------------------------------------------------------//
// This function return the center vertex
Vertex EquilateralTriangle::getCenter() const
{
	return m_triangle.getCenter();
}

//----------------------------------------------------------------------//
// This function checks if the scale of the triangle woreked
// If the scale wored, the data members will change.
bool EquilateralTriangle::scale(double factor)
{
	return m_triangle.scale(factor);
}

//----------------------------------------------------------------------//
// we set all values to default
void EquilateralTriangle::setDeafualt()
{
	Vertex vertices[3];

	vertices[0].m_row = 20;
	vertices[0].m_col = 20;

	vertices[1].m_col = 30;
	vertices[1].m_row = 20;

	vertices[2].m_row = 20 + sqrt(75);
	vertices[2].m_col = 25;

	m_triangle = IsoscelesTriangle(vertices);
}

//----------------------------------------------------------------------//