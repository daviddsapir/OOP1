#pragma once


/******************* include section ************************/
#include<fstream>
#include <iostream>
#include "Location.h"
#include <vector>
#include <string>


// we mention we use the classes Player & Enemy
class Player;
class Enemy;


/******************** class section **********************/
class Map
{
public:
	//C-tor.
	Map();

	// d-tor
	~Map();


	// loads the next map of the world.
	void loadNextMap();
	
	// intilizes the maps data.
	void intilizeMapData();

	// gets the stage num
	int getStageNum() const;

	// paints the map to the stdout
	void paintMap() const;
	

	// returns the map size.
	int getMapSize() const;

	// returns the amount of map coins
	int getMapCoins() const;


	// decreases the amount of coins in the map.
	void decreaseMapCoins();


	// sets the char of map that 
	void setMapChar(const int& row, const int& col, const char& c);
	

	// gets the current paint boards stats.
	char getPanitBoardChar(const int& row, const int& col) const;
	

	//updates the map of the world. 
	void updateMap();
	

	// sets the enemies is the world.
	void setEnemies(std::vector<Enemy>&, Player&);


	// counts the amount of coins in the world.
	void countNumCoins();


	// checks if there is more stages left
	bool isStageLeft();

	
	// checks if the current position in the world
	// hold the coin(*) charcter
	bool isCoin(const int& row, const int& col) const;
	
	
	// checks if the current position in the world
	// hold the pipe(-) charcter
	bool isPipe(const int& row, const int& col) const;
	
	
	// checks if the current position in the world
	// hold the block(#) charcter
	bool isBlock(const int& row, const int& col) const;
	
	
	// checks if the current position in the world
	// hold the empty(' ') charcter
	bool isEmpty(const int& row, const int& col) const;
	
	
	// checks if the current position in the world
	// hold the ladder(H) charcter
	bool isLadder(const int& row, const int& col) const;

private:
	int m_stageNum = 0, m_coins = 0;
	bool newStageExist = true;


	/********* auxillary private functions *************/

	// returns the map size.
	void setMapSize(int);

	//clears the screen.
	void clearScrean() const;

	// sets the maps stats.
	void setMapData();

	// Opens the file to read the map of the world from.
	void openFile(std::ifstream& inputFile);

	// Read the size of the world and sets it.
	void setMapSize();


	// vector that sets the charcters of the world.
    std::vector<std::string> m_paintBoard;

	// var to connet to the file to read the map from
	std::ifstream m_fileInputData;

	// hold the map size.
	int m_mapSize;
};

