#pragma once

/**************** include section *********************/
#include "Location.h"
#include "Map.h"
#include "Macros.h"
#include <vector>
class Enemy;


// the player object in our game
class Player {
public:

	// c-tor that gives the player our world.
	Player(Map& map,std::vector<Enemy>& enemies);
	
	// returns the current players position.
	Location getPlayerPos() const;


	// stores the current players  position.
	Location getBeginPlayerPos() const;


	// sets the new players position.
	void setPlayerPos(const Location& newLocation);


	// returns the players old symbol i.e. switches between 
	// player on ladder and no on ladder.
	char getPlayerSymbol() const;


	// returns the amount of lifes left to the player.
	int getPlayerLifes() const;


	// decreaces the players life by 1.
	void lostLife();
	

	// moves the player (the object)
	void movePlayer(char&);

	// set number of coins player have.
	void addPlayerCoins(const int numOfCoins);

	// Get number of coins player have.
	int getPlayerCoins() const;


	//Intilize player data.
	// i.e. the player position in the world,
	// amount of life.
	void intilizePlayer();

	// find the current location
	// of the player in the world.
	void findPlayerPos();


private:
	// we defines symbols that will help us handle
	// few cases

	// vector that holds the enemies.
	std::vector<Enemy> *m_enemies;

	char m_symbol = '@';


	// Characteristics of the player
	int m_lifes = LIFES,
		m_coins = 0;

	// The world within which the player 'lives'
	Map* m_worldMap;

	// a auxillary struct that will hold the 
	// location of our object (player).
	Location m_playerPos,
		m_beginLocation;

	// reads the next move of the player.
	int readKB();


	// set the new players move (to the new location)
	void setBtnMovments(char& c, Location&, char&);


	// a function that collects the coin and increases
	// the amount of coins collected.
	void collectCoint();


	//Ladder handle functions.
	bool isMovingOffLadder(const Location&);


	//Fall handle functions.
	void fallHandler(Location& newLocation);
	bool isBottomNotEmpty(const Location&);

	bool isOnFloor(const char& move) const;

	bool isOnPipe() const;


	//Enemy handle functions.
	bool enemyIncounter(const Location&);


	// checks if the next move is valid.
	bool isMoveValid(const Location&);


	// this function checks if the next movemnt
	// of the player is ligal.
	bool isNextMoveValid(const Location&, const char&);
};
