#pragma once
#include "Location.h"
#include "Map.h"
#include "Player.h"


class Enemy 
{
public:
	//c-tors
	Enemy() = default;
	Enemy(const int&, const int&, Map&, Player&);

	// d-tor
	~Enemy();


	//returns the location of the enemy
	Location getEnemyPos() const;


	// returns the begining enemy position
	// when we start a new stage.
	Location getBeginEnemyPos() const;


	// sets the enemy new position in the map of the world.
	void setEnemyPos(const Location& location);


	// move the enemy object in the world. 
	void moveEnemy();


private:

	// auxillary function to the function moveEnemy.
	// this function read the new movments that the 
	// enemy wants to do.
	void setEnemyMovment(Location&, int&);


	// checks if the enemy doesn't get out of the ligal zone of the map.
	bool isMoveValid(const Location& newLocation);


	// checks wether the movement of the enemy is ligal or not. 
	bool isligalMove(const Location& next_enemy_location, const int&);


	bool isOnFloor( const int&) const;

	bool isOnPipe(const int&)const;

	bool isOnLadder(const Location& next_enemy_location);
	

	//Ladder handle functions.
	bool isMovingOffLadder(const Location& newLocation);

	
	// checks if the player if found in that location
	// int the map and if it is, the enemy kills him 
	bool IsPlayerKilled(const int& row, const int& col);

	//Fall handle functions.
	void fallHandler(Location newLocation);

	// a bollian function that returns if the bottom is empty 
	// or not. This function is needed to know if the enemy
	// should fall or not.
	bool isBottomNotEmpty(const Location& newLocation) const;


	// the current and the begin location of the enemy.
	Location m_currLocation,m_beginLocation;


	// the world that the enemy lives in.
	Map* m_worldMap;


	// the player in the world.
	// to have knowelge about his 
	// location and distance if needed.
	Player* m_player;

	int numOfTries = 0;
};

