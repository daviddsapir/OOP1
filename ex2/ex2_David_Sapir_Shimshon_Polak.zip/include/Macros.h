#pragma once

/*********************** Macros *****************************
In Macros we hold all the consts and enumbs in our program
************************************************************/

const char
EMPTY = ' ',
PLAYER = '@',
BLOCK = '#',
COIN = '*',
LADDER = 'H',
ENEMY = '%',
PIPE = '-',
ON_LADDER = 'S',
EXIT_GAME = (char)27;

const int LIFES = 3;


enum ENEMY_MOVME { UP, DOWN, LEFT, RIGHT };