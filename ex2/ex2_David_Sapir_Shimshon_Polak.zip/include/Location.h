#pragma once


// struct to know what is the location of the objects
struct Location
{
    explicit Location(int row, int col) : row(row), col(col) {}
    int row;
    int col;
};
