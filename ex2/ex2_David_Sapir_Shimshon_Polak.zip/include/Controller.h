#pragma once

/************* include section *********************/
#include "Map.h"
#include "Player.h"
#include "Macros.h"
#include "io.h"
#include "Enemy.h"
#include <vector>



/**************** class section ********************/
class Controller {
public:

	//c-tor
	Controller();

	// turns on the game.
	void startGame();


private:
	int m_stage = 1;


	// hold the map of our world
	Map m_worldMap;

	// vector that holds the enemies.
	std::vector<Enemy> m_enemies;

	// The player 
	Player m_player;


	// prints the players stats.
	void printStats() const;


	// prints game over and afterwards prints the players score
	void printGameOver() const;


	// turns on the game.
	void playTheGame();

	// Sets the next stage of the game (sets the new map) 
	void setNextStage();


	// reloads the player & enemies to ther begining place.
	void anotherLifeReloadMap();


	// exitsts the game (the user entered ESC)
	void exitGame() const;


	// prints the players score
	void printPlayerScore() const;


	// prits player won the game and his score.
	void printYouWon() const;


	// moves the player & enemies
	void moveCharcters();


	// ends the game with the wanted display.
	void endGame() const;


	//Check if the player had lost a life.
	void checkIfPlayerLostLife(int&);


	//Print the player on the map.
	void printPlayerNextStep() const;


	//Print the Enemy on the map.
	void printEnemyNextStep(const Location &) const;
};