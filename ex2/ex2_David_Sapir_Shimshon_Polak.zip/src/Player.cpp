/************ include section ****************/
#include "Player.h"
#include "io.h"
#include "Macros.h"
#include "Location.h"
#include <vector>
#include "Enemy.h"

//************************************************************************
//The c-tor intilize map pointer, and player position
Player::Player(Map& map, std::vector<Enemy>& enemies)
	:m_worldMap(&map), m_playerPos(0, 0)
	, m_beginLocation(0, 0)
	, m_enemies(&enemies)
{
	findPlayerPos();
}


//************************************************************************
//Get player position.
Location Player::getPlayerPos() const
{
	return m_playerPos;
}


//************************************************************************
//Get player starting map position.
Location Player::getBeginPlayerPos() const
{
	return m_beginLocation;
}


//************************************************************************
//Set player position
void Player::setPlayerPos(const Location& newLocation)
{
	m_playerPos = newLocation;
}


//************************************************************************
//Get player symbol.
char Player::getPlayerSymbol() const
{
	return m_symbol;
}


//************************************************************************
//Get player number of lifes left.
int Player::getPlayerLifes() const
{
	return m_lifes;
}


//************************************************************************
//Lose player 1 life.
void Player::lostLife()
{
	m_lifes--;
}


//************************************************************************
//Find the player position in map.
void Player::findPlayerPos()
{
	int map_size = m_worldMap->getMapSize();

	for (int row = 0; row < map_size; row++)
		for (int col = 0; col < map_size; col++)
			if (m_worldMap->getPanitBoardChar(row, col) == PLAYER) {

				setPlayerPos(Location(row, col));

				m_worldMap->setMapChar(row, col, EMPTY);

				m_beginLocation = Location(row, col);

				return;
			}
}


//************************************************************************
// the movemnt function soutld return a bool we want to know if the player did a good moment.
void Player::movePlayer(char& exit_game) {
	char inputBtn = ' ';
	bool anotherTurn = false;
	Location newPlayerPos(getPlayerPos());

	while (!anotherTurn && m_worldMap->getMapCoins() > 0) {
		anotherTurn = false;

		newPlayerPos = getPlayerPos();
		if (isBottomNotEmpty(newPlayerPos)) {

			setBtnMovments(inputBtn, newPlayerPos, exit_game);
			if (exit_game == EXIT_GAME) return;

			if (anotherTurn = isNextMoveValid(newPlayerPos, inputBtn)) {
				setPlayerPos(newPlayerPos);
			}
		}
		else if (newPlayerPos.row < m_worldMap->getMapSize() - 1)
			fallHandler(newPlayerPos);
	}
}


//************************************************************************
// add to existed coins to the player by numOfCoins.
void Player::addPlayerCoins(const int numOfCoins)
{
	m_coins += numOfCoins;
}


//************************************************************************
// gets the coins the player stepped on.
int Player::getPlayerCoins() const
{
	return m_coins;
}


//************************************************************************
//Check is the next move is valid according to the position.
bool Player::isNextMoveValid(const Location& newLocation, const char& c)
{
	int row = newLocation.row,
		col= newLocation.col;

	if (isMoveValid(newLocation)) {

		if (enemyIncounter(newLocation))
			m_lifes--;

		else if (m_worldMap->isLadder(row, col))
			m_symbol = ON_LADDER;

		else if (isMovingOffLadder(newLocation))
			m_symbol = PLAYER;

		else if (m_worldMap->isCoin(row, col)) {
			collectCoint();
			m_worldMap->setMapChar(row, col, EMPTY);
		}

		else if (c != KB_UP &&( isOnFloor(c) || isOnPipe()))
			m_symbol = PLAYER;

		else
			return false;

		return true;
	}
	return false;
}


/*********************** enemyIncounter ***************************
if the player incounters an enemy we will want to decrease his 
life and reset the enemy and player location
******************************************************************/
bool Player::enemyIncounter(const Location& newLocation) 
{
	for (int i = 0; i < m_enemies->size(); i++) {
		if (newLocation.col == (*m_enemies)[i].getEnemyPos().col &&
			newLocation.row == (*m_enemies)[i].getEnemyPos().row) {

			m_lifes--;

			return true;
		}
	}

	return false;
}


//************************************************************************
//Set the buttons movments on map.
void Player::setBtnMovments(char& c, Location& newPlayerPos, char& exit_game)
{
	c = readKB();
	if ((char)c == EXIT_GAME) {
		exit_game = EXIT_GAME;
	}

	switch (c) {
	case KB_LEFT:
		(newPlayerPos.col)--;
		break;
	case KB_RIGHT:
		(newPlayerPos.col)++;
		break;
	case KB_UP:
		newPlayerPos.row--;
		break;
	case KB_DOWN:
		newPlayerPos.row++;
		break;
	}
}


//************************************************************************
//Check is legel move to make.
bool Player::isMoveValid(const Location& newLocation)
{
	return(newLocation.row >= 0
		&& newLocation.col >= 0
		&& newLocation.row < m_worldMap->getMapSize()
		&& newLocation.col < m_worldMap->getMapSize()
		&& !(m_worldMap->isBlock(newLocation.row,newLocation.col)));
}


//************************************************************************
//Read the keyboard inputs.
int Player::readKB() {
	int c;

	do {
		c = Keyboard::getch();
	} while (c != SPECIAL_KEY && c != EXIT_GAME);

	if (c == EXIT_GAME)
		return c;
	else
		return (c = Keyboard::getch());
}


//************************************************************************
//Collect coint to player.
void Player::collectCoint()
{
	m_coins += 2*m_worldMap->getStageNum();
	m_worldMap->decreaseMapCoins();
	m_symbol = PLAYER;
}


//************************************************************************
//check if player can leave off the ladder if on floor or to nearby block. 
bool Player::isMovingOffLadder(const Location& newLocation)
{
	 if (m_worldMap->isLadder(m_playerPos.row,m_playerPos.col)&& 
		(m_worldMap->isBlock(newLocation.row + 1,newLocation.col)
		||(m_worldMap->isEmpty(m_playerPos.row - 1, m_playerPos.col)))) {
		return true;
	}	

	return false;
}

//************************fall handler************************************
//Handle fall event when beneath player is EMPTY.
void Player::fallHandler(Location& newLocation) {
	newLocation.row += 1;

	if (m_worldMap->isCoin(newLocation.row, newLocation.col)) {

		collectCoint();
		m_worldMap->setMapChar(newLocation.row, newLocation.col, EMPTY);

	}

	enemyIncounter(newLocation);
		
	setPlayerPos(newLocation);
	m_worldMap->updateMap();

	Screen::setLocation(getPlayerPos());
	std::cout << getPlayerSymbol();
}


//************************************************************************
//Check if the bottom of positon is not empty.
bool Player::isBottomNotEmpty(const Location& newLocation)
{
	return m_worldMap->isBlock(m_playerPos.row + 1, m_playerPos.col) ||
		m_worldMap->isLadder(m_playerPos.row + 1, m_playerPos.col) ||
		m_worldMap->isLadder(m_playerPos.row, m_playerPos.col) || 
		isOnPipe();
}

//************************************************************************
//Check if not on ladder allow right left.
bool Player::isOnFloor(const char& move)const
{
	return !m_worldMap->isLadder(m_playerPos.row, m_playerPos.col)
		&& (move == KB_LEFT || move == KB_RIGHT);
}

//************************************************************************
//Check if on Pipe.
bool Player::isOnPipe() const
{
	return (m_worldMap->isPipe(m_playerPos.row, m_playerPos.col));
}


//************************************************************************
//Intilize player data.
void Player::intilizePlayer()
{
	m_symbol = PLAYER;	
}