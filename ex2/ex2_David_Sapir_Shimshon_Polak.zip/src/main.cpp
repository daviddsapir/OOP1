#include <iostream>
#include <cstdlib>
#include "Controller.h"



int main()
{
	Controller c;

	c.startGame();

	return EXIT_SUCCESS;
}