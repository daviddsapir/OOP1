/*********** include section ******************/
#include"Map.h"
#include <string>
#include<fstream>
#include <iostream>
#include <Macros.h>
#include "Enemy.h"
#include "io.h"


//using section..
using std::ifstream;
using std::cerr;
using std::endl;
using std::getline;
using std::cout;
using std::string;


// c-tor
Map::Map()
	:m_mapSize(20)
{
	openFile(m_fileInputData);
	intilizeMapData();
}


// d - tor
Map::~Map()
{}


/**************** loadNextMap ********************
This function loads the next next map of 
the game.
*************************************************/
void Map::loadNextMap() {
		m_paintBoard.clear();
		intilizeMapData();
		updateMap();
}

/************* intilizeMapData ****************
This function intilizes the map data.
**********************************************/
void Map::intilizeMapData() {
	m_stageNum++;
	setMapSize();
	setMapData();
}


/******* getStageNum *********
Returns the stage number.
*****************************/
int Map::getStageNum() const
{
	return m_stageNum;
}


/******* updateMap *********
This function clears the 
screan and then prints the 
new map updated after the 
player did his move.
***************************/
void Map::updateMap()
{
	clearScrean();
	paintMap();
}


/*************************** setEnemies ********************************
This functions sets the enemies positions and puts the enemies in 
the vector that hold the enemies of our world.
***********************************************************************/
void Map::setEnemies(std::vector<Enemy>& enemies, Player& m_player)
{
	int enemyAmount = 0;

	for (int row = 0; row < m_mapSize; row++)
		for (int col = 0; col < m_mapSize; col++) {
			// finds enemy in map and inserts into the vector that 
			// hold all the enemies.
			if (getPanitBoardChar(row, col) == ENEMY) {
				m_paintBoard[row][col] = EMPTY;
				enemies.push_back(Enemy(row, col, *this, m_player));
			}
		}
}


//************************************************************************
//checks if the current position in the world
// hold the coin(*) charcter
bool Map::isCoin(const int& row, const int& col) const
{
	return getPanitBoardChar(row,col) == COIN ;
}


//************************************************************************
// checks if the current position in the world
// hold the pipe(-) charcter
bool Map::isPipe(const int& row, const int& col) const
{
	return (getPanitBoardChar
	(row, col) == PIPE);
}


//************************************************************************
// checks if the current position in the world
// hold the block(#) charcter
bool Map::isBlock(const int& row, const int& col) const
{
	return(getPanitBoardChar(row, col) == BLOCK);
}


//************************************************************************
// checks if the current position in the world
// hold the empty(' ') charcter
bool Map::isEmpty(const int& row, const int& col) const
{
	return(getPanitBoardChar(row, col) == EMPTY);
}


//************************Ladder Handler************************************
// checks if the current position in the world
// hold the ladder(H) charcter
bool Map::isLadder(const int& row, const int& col) const
{
	return (getPanitBoardChar(row, col) == LADDER);
}


//************************************************************************
// returns the map size.
void Map::setMapSize(int mapSize)
{
	m_mapSize = mapSize;
}


//************************************************************************
// Opens the file to read the map of the world from.
void Map::openFile(ifstream &inputFile)
{
	inputFile.open("Board.txt");
	if (!inputFile.is_open()) {
		cerr << "input file not found" << endl;
		exit(EXIT_FAILURE);
	}

}


//************************************************************************
// Read the size of the world and sets it.
void Map::setMapSize() {
	string inputSize;
	getline(m_fileInputData, inputSize);
	m_mapSize = stoi(inputSize);
	m_paintBoard = std::vector(m_mapSize,
		std::string(m_mapSize, ' '));
}


//************************************************************************
// Return the map size
int Map::getMapSize() const
{
	return m_mapSize;
}


//************************************************************************
// decreases the amount of coins in the map.
void Map::decreaseMapCoins()
{
	if(m_coins>0)
	m_coins--;
}


//************************************************************************
// sets the paint board that prints the world of the game.
void Map::setMapChar(const int& row, const int& col, const char& c)
{
	m_paintBoard[row][col] = c;
}


//************************************************************************
// gets the current paint boards stats.
char Map::getPanitBoardChar(const int& row, const int& col) const
{
	return m_paintBoard[row][col];
}


//************************************************************************
// paints the map to the stdout
void Map::paintMap() const
{
	for (int i = 0; i < m_mapSize; i++)
		cout << m_paintBoard[i] << endl;
}


//************************************************************************
// sets the maps stats.
void Map::setMapData()
{
		int row = 0;
		string input_str_row;
		while (row < m_mapSize) {
			getline(m_fileInputData, input_str_row);
			m_paintBoard[row] = input_str_row;
			row++;
		}
		countNumCoins();
}


//************************************************************************
//clears the screen.
void Map::clearScrean() const
{
	Screen::resetLocation;
	system("cls");
}


//************************************************************************
//Set counter of coins existed in the map.
void Map::countNumCoins()
{
	for (int row = 0; row < m_mapSize; row++)
		for (int col = 0; col < m_mapSize; col++)
			if (getPanitBoardChar(row, col) == COIN)
				m_coins++;
}


//************************************************************************
// checks if there is more stages left
bool Map::isStageLeft()
{
	m_fileInputData.get();
	if (!m_fileInputData.eof()) 
		return true;

	return false;
}


//************************************************************************
// returns the amount of map coins
int Map::getMapCoins() const{
	return m_coins;
}

