/********************* include section **************************/
#include"Enemy.h"
#include <time.h>
#include "Macros.h"
#include "Location.h"


/****************************** c-tors ***************************************/
Enemy::~Enemy()  
{}


Enemy::Enemy(const int& row, const int& col, Map& worldmap, Player& m_player)
	: m_currLocation(row, col),
	m_worldMap(&worldmap),
	m_beginLocation(row, col),
	m_player(&m_player)
{}


//************************************************************************
//Get enemy position.
Location Enemy::getEnemyPos() const
{
	return m_currLocation;
}


//************************************************************************
// returns the begining enemy position
// when we start a new stage.
Location Enemy::getBeginEnemyPos() const
{
	return m_beginLocation;
}


//************************************************************************
//Set enemy position.
void Enemy::setEnemyPos(const Location& location)
{
	m_currLocation = location;
}


//************************************************************************
// move the enemy object in the world. 
void Enemy::moveEnemy()
{
	srand((unsigned)time(NULL));
	Location next_enemy_location(getEnemyPos());
	int move = 0;
	bool anotherTurn = false;
	numOfTries = 0;

	while(!anotherTurn){

		next_enemy_location = getEnemyPos();

		if (isBottomNotEmpty(next_enemy_location)) {

			move = rand() % 4;

			setEnemyMovment(next_enemy_location, move);

			anotherTurn = isligalMove(next_enemy_location, move);

		}else 
			fallHandler(next_enemy_location);
	}
	setEnemyPos(next_enemy_location);
}


//************************************************************************
//getss the new enemy movement.
// auxillary function to the function moveEnemy.
// this function read the new movments that the 
// enemy wants to do.
void Enemy::setEnemyMovment(Location& next_enemy_location, int &move)
{
	switch (move) {
	case UP:
		(next_enemy_location.row)--;
		break;
	case DOWN:
		(next_enemy_location.row)++;
		break;
	case LEFT:
		(next_enemy_location.col)--;
		break;
	case RIGHT:
		(next_enemy_location.col)++;
		break;
	}
}


//************************************************************************
//Check if the next move is legal.
bool Enemy::isligalMove(const Location& next_enemy_location, const int& move)
{
	int row = next_enemy_location.row,
		col = next_enemy_location.col;

	if (isMoveValid(next_enemy_location)) {
		if (IsPlayerKilled(row, col) || isOnLadder(next_enemy_location)
			|| isOnFloor(move) || isOnPipe(move))
			return true;
		else
			return false;
	}
	return false;
}


//************************************************************************
//Check is legel move to make.
//checks if the enemy doesn't get out of the ligal zone of the map.
bool Enemy::isMoveValid(const Location& newLocation)
{
	return(newLocation.row >= 0
		&& newLocation.col >= 0
		&& newLocation.row < m_worldMap->getMapSize()
		&& newLocation.col < m_worldMap->getMapSize()
		&& !m_worldMap->isBlock(newLocation.row, newLocation.col));
}


//************************************************************************
//Hadnle floor event if successful return true..
bool Enemy::isOnFloor(const int& move)const
{
	return !m_worldMap->isLadder(m_currLocation.row, m_currLocation.col) 
		&& (move == LEFT || move == RIGHT);
}

bool Enemy::isOnPipe(const int& move) const
{
	return (m_worldMap->isPipe(m_currLocation.row, m_currLocation.col) &&
		move != UP);
}

bool Enemy::isOnLadder(const Location& next_enemy_location)
{
	return m_worldMap->isLadder(next_enemy_location.row, next_enemy_location.col) ||
		isMovingOffLadder(next_enemy_location);
}


//***********************isMovingOffLadder**********************************
//If the enemy want to move off ladder.
bool Enemy::isMovingOffLadder(const Location& newLocation) {
	int row = m_currLocation.row, col = m_currLocation.col;
	if (m_worldMap->isLadder(row,col) &&
		(m_worldMap->isBlock(newLocation.row + 1, newLocation.col)|| 
			(m_worldMap->isEmpty(row - 1,col)))){
		return true;
	}

	return false;
}


//**************************IsPlayerKilled************************************
//Check if player in the next step.
bool Enemy::IsPlayerKilled(const int& row, const int& col)
{
	//Check if equel player position.
	if (row == m_player->getPlayerPos().row && col == m_player->getPlayerPos().col) {
		m_player->lostLife();
		return true;
	}
	return false;
}


//**************************fallHandler************************************
//Handle fall event.
void Enemy::fallHandler(Location newLocation)
{
	newLocation.row += 1;
	setEnemyPos(newLocation);
}


//***************************isBottomNotEmpty***********************************
//Check if under enemy standing on block or ladder or if he is on ladder or pipe.
bool Enemy::isBottomNotEmpty(const Location& newLocation) const
{
	int row = m_currLocation.row, col = m_currLocation.col;
	return (m_worldMap->isBlock(row + 1, col) ||
		m_worldMap->isLadder(row + 1, col) ||
		m_worldMap->isPipe(row, col));
}