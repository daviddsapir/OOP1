#include "..\include\Controller.h"
#include <iostream>
#include <cstdlib>


// using section
using std::cout;
using std::endl;


// c-tor
Controller::Controller() :m_worldMap(), m_player(m_worldMap,m_enemies) {}


/*********************** startGame *******************************
This function calls functions that set the map of the world, the
enemies and the player
******************************************************************/
void Controller::startGame()
{
	m_worldMap.setEnemies(m_enemies, m_player);
	m_worldMap.paintMap();
	playTheGame();
}

/****************** printStageDetails *****************************
This function prints the current stage ditails.
This function is callded every time the player does a move
******************************************************************/
void Controller::printStats() const {
	cout << "___________\n\nStage :" << m_worldMap.getStageNum()
		<< "\nlives :" << m_player.getPlayerLifes()
		<< "\nPoints:" << m_player.getPlayerCoins()
		<< "\n___________\n";
	Screen::resetLocation;
}


/***************** playTheGame ***********************
This function is the main function that controls the 
enenmies, the player moevment and the printing of the 
world map.
*****************************************************/
void Controller::playTheGame()
{

	printPlayerNextStep();

	while (m_player.getPlayerLifes() > 0) {
		if (m_worldMap.getMapCoins() > 0) {

			//Print the stats beneath the map.
			Screen::setLocation(Location(m_worldMap.getMapSize(), 0));
			printStats();

			moveCharcters();

		}
		else if (m_worldMap.isStageLeft()){
			m_player.addPlayerCoins((50 * m_worldMap.getStageNum()));
			setNextStage();
		}
		else {
			//Add last stage bonus coins.
			m_player.addPlayerCoins((50 * m_worldMap.getStageNum()));
			break;
		}
	}

	endGame();

	exit(EXIT_SUCCESS);
}


/*************** moveCharcters *******************
This is an auxillary function to the function
playTheGame.
This function moves the charcters (the player &
the enemies) of our game.
*************************************************/
void Controller::moveCharcters()
{
	char exit_game = false;
	int curr_player_life = m_player.getPlayerLifes();

	// moves player and checks if ESC is pressed.
	m_player.movePlayer(exit_game);
	if (exit_game) exitGame();

	checkIfPlayerLostLife(curr_player_life);

	m_worldMap.updateMap();

	// moves enemies
	for (int i = 0; i < m_enemies.size(); i++) {
		m_enemies[i].moveEnemy();
		printEnemyNextStep(m_enemies[i].getEnemyPos());
		checkIfPlayerLostLife(curr_player_life);
	}

	printPlayerNextStep();

}


/************** endGame ******************
prints the right output when finishing the 
game.
*****************************************/
void Controller::endGame() const
{
	system("cls");
	if (m_player.getPlayerLifes() <= 0)
		printGameOver();
	else
		printYouWon();
}


/************* setNextStage **************
Sets the nest stages data and world.
*****************************************/
void Controller::setNextStage() {
	m_enemies.clear();
	m_worldMap.loadNextMap();
	m_player.findPlayerPos();
	m_player.intilizePlayer();
	m_worldMap.setEnemies(m_enemies, m_player);
}


/*************************** anotherLifeReloadMap *********************************
Reloads the map from the begining if the player got hit by the enemies.
**********************************************************************************/
void Controller::anotherLifeReloadMap()
{

	m_worldMap.updateMap();

	m_player.setPlayerPos(m_player.getBeginPlayerPos());
	m_player.intilizePlayer();

	printPlayerNextStep();

	for (int i = 0; i < m_enemies.size(); i++) {
		m_enemies[i].setEnemyPos(m_enemies[i].getBeginEnemyPos());
	}

}


/********************* exitGame ***********************
Exits the game: clears the screen and prints exit game
******************************************************/
void Controller::exitGame() const
{
	system("cls");
	cout << "_____________\n\n"
		<< "Exit Game..."
		<< "\n_____________\n";

	exit(EXIT_SUCCESS);
}


/******************* printPlayerScore *********************
Prints the players score.
**********************************************************/
void Controller::printPlayerScore() const
{
	cout << "------------ Your score ----------------\n";
	printStats();
}


/******************* printYouWon ************************
Prints that the player won and afterwards displays the
players score.
********************************************************/
void Controller::printYouWon() const
{
	cout << "------------ Your Won!!!! ------------\n";
	printPlayerScore();
}


/****************** printGameOver **********************
Prints that the player lost and afterwards displays the
players score.
*******************************************************/
void Controller::printGameOver() const
{
	cout << "------------- Game Over ------------\n";
	printPlayerScore();
}


/****************** checkIfPlayerLostLife ***************
Check if the player lost life in turn 
if does restart the positions of player and enemys.
*********************************************************/
void Controller::checkIfPlayerLostLife(int &curr_player_life)
{
	if (curr_player_life > m_player.getPlayerLifes()) {
		curr_player_life = m_player.getPlayerLifes();
		anotherLifeReloadMap();
	}
}


/****************** printPlayerNextStep ***************
Print the player on screen in the new position.
*******************************************************/
void Controller::printPlayerNextStep() const {
	Screen::resetLocation;
	Screen::setLocation(m_player.getPlayerPos());
	std::cout << m_player.getPlayerSymbol();
	Screen::resetLocation;
}


/****************** printEnemyNextStep ***************
Print the Enemy on screen in the new position.
*******************************************************/
void Controller::printEnemyNextStep(const Location &enemyLocation) const {
	Screen::resetLocation;
	Screen::setLocation(enemyLocation);
	std::cout << ENEMY;
	Screen::resetLocation;
}