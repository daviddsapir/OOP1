=====================================================================

OOP, ex2
========
by: David Sapir & Shimson Polak 
id: David - 208917351
    Shimson - 315605642 


			Load Runner.
=====================================================================

  			Description
                     =================	
This program mimic the Load Runner game in the cmd.
The purpose: collect coins in the map, and avoid the enemies.
=====================================================================

                       	   Design
                      =================
Controller
Role:The controller runs the game and hold Map, Player and Enemies objects.

Map
Role:The Map holds all the game object in the game and collecting relevent data
	, each symbol in the map reprasant the following:
	@ - Player.
	% - Enemy.
	# - Floor & Walls: block movment.
	- - Pipe: allow to move left right and down.
	H - Ladder:allow to move up down ,if block to left allow move right and left.
	* - Coin:can be collected by the player.

Player
Role: 
	The player controlled by the user, the movement allowed by the user position,
	The player hold a pointer to the map know the items positions..
	The player hold the enemies vector pointer to know their position
	 on map and notify being hit.

Enemy
Role: 
	The enemies controlled by the computers, 
	their movments are similer to the Player but not exect
	The Enemy hold a pointer to the map know the items positions.
	The Enemy hold the player pointer to know his position on map
	 and notify him being hit.

=======================================================================

                         Included files
                        =================
There are 4 object files built by us:
1.)Controller.cpp - This class controll the running of the game by:
	1.) moving the player.
	2.) moving the enemies.
	3.) loding the map.
	The controller run the game until player lifes are 0, or the player collected all 
	the coins in the game.
2.)Map.cpp - This class the details of the map such as:player,enemies,ladders wall, coins.

3.)Player.cpp - 
This class control the player movement by 
getting input from keyboard: UP,DOWN,LEFT,RIGHT,ESCAPE

4.)Enemy.cpp - 
This class control the enemy movement in the map.

5.)Macros.h - 
hold the const used in the files.

Also every '.cpp' file has a header file.
4 source + 5 header = 9 files in total.

note: Location.h,io.h was given by instructor.
=====================================================================

                           Data Structure
                          ==============
=====================================================================

                          Algorithms worth mention:
                        =============================
The enemies choose to which location to go by modulo random number by 4.
Each number reprasnt a diraction 0-UP ,1-DOWN,2-LEFT,3-RIGHT.
Each given diraction the enemy check if it is valid , if does he will
by the diraction, if not,another random  number will be given to the enemy.
=====================================================================

			Known bugs
 		 =============================
1.)Enemies become invisble when waiting Player to make a move after falling.

=====================================================================

			Comments
=====================================================================
1.)On each turn the player the enemies start moving as well
2.)Each score is calculate 2 * (Stage number)
by finishing stage you get 50 * (Stage number).
3.)On player 0 lives the game ends
4.)For costume board.txt map, make sure the data map are valid.
and no endline after the last map.















