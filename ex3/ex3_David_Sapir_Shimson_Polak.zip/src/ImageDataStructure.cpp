#pragma once
#include "ImageDataStructure.h"
#include "Image.h"
#include <iostream>


ImageDataStructure::ImageDataStructure()
	: m_imageData(nullptr), m_hight(0), m_width(0)
{}
//endof ImageDataStructure


//------------------ ImageDataStructure -----------------------
ImageDataStructure::ImageDataStructure(const unsigned int& h,
	const unsigned int& w,
	const unsigned char& pixel)
	: m_hight(h), m_width(w)
{
	buildImageDataStructure(h, w, pixel);
}
//endof ImageDataStructure



//------------------ d-tor -----------------------
// The d-tor free the memory we allocate for the 
// 2D-array of pixels. 
ImageDataStructure::~ImageDataStructure()
{
	freeMemory();
}
//endof ImageDataStructure


//---------------------- setImagePixels ---------------------------
// This function sets the pixels of the current image.
void ImageDataStructure::setImagePixels(const unsigned char& pixel)
{
	for (int i = 0; i < m_hight; i++)
		for (int j = 0; j < m_width; j++)
			m_imageData[i][j] = pixel;
}
//endof setPixels


//----------------- getPixelColor ----------------------
unsigned char ImageDataStructure::getPixelColor
(const int& row, const int& col) const
{
	return m_imageData[row][col].getColor();
}
//endof getPixelColor


//------------------ setPixelColor -------------------
void ImageDataStructure::setPixelColor
(const int& row, const int& col, const char& color)
{
	m_imageData[row][col].setColor(color);
}
//endof setPixel


//---------------- freeMemory -------------------
// This function frees the memory we allocated
void ImageDataStructure::freeMemory()
{
	for (int i = 0; i < m_hight; i++)
		delete[] m_imageData[i];

	delete[] m_imageData;
}
//endof freeMemory


//--------------- buildImageDataStructure ------------------
void ImageDataStructure::buildImageDataStructure
(const int& h, const int& w, const unsigned char& pixel)
{
	m_hight = h;
	m_width = w;
	m_imageData = new Pixel * [h];
	for (int i = 0; i < h; i++)
		m_imageData[i] = new Pixel[w];

	setImagePixels(pixel);
}
//endof buildImageDataStructure


//--------------------- copyImage -------------------------
void ImageDataStructure::copyImage
(const ImageDataStructure& otherImageData)
{
	for (int i = 0; i < m_hight; i++)
		for (int j = 0; j < m_width; j++)
			m_imageData[i][j].setColor(otherImageData.getPixelColor(i, j));
}
//endof copyImage


//---------------------- getPixel -----------------------
Pixel& ImageDataStructure::getPixel
(const unsigned int& row, const unsigned int& col)
{
	return m_imageData[row][col];
}
//endof paintImage


//----------------------- getPixel ----------------------------
const Pixel& ImageDataStructure::getPixel
(const unsigned int& row, const unsigned int& col) const
{
	return m_imageData[row][col];
}
//endof getPixel


//-------------------- operator= ---------------------
ImageDataStructure& ImageDataStructure::operator=
(const ImageDataStructure& other)
{
	if (this != &other) {
		freeMemory();
		buildImageDataStructure(other.getHight(),
			other.getWidth(), ' ');
		copyImage(other);
	}

	return *this;
}
//endof operator=


//---------------- getHight -------------------
// This function retru nthe hight of an image 
int ImageDataStructure::getHight() const
{
	return m_hight;
}
//endof getHight


//---------------- getWidth -------------------
// This function retru nthe width of an image 
int ImageDataStructure::getWidth() const
{
	return m_width;
}
//endof getWidth


