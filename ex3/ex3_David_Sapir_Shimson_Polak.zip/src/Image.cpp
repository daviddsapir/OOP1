//---------- include section ---------------
#include "Image.h"
#include <iostream>
#include <algorithm> 

// c-tor
Image::Image()
{} 
//endof Image


// c-tor
Image::Image(const int& hight, const int& width)
	:m_imageData(hight, width)
{} 
//endof Image


// c-tor
Image::Image(const int& h, const int& w, const unsigned char pixel)
	: m_imageData(h, w, pixel)
{}
//endof Image


// copy c-tor
Image::Image(const Image& other)
	: m_imageData(other.getHight(), other.getWidth())
{
	m_imageData.copyImage(other.m_imageData);
}
//endof Image


// return the hight of the image
int Image::getHight() const
{
	return m_imageData.getHight();
}
//endof getHight


// return the width of the image
int Image::getWidth() const
{
	return m_imageData.getWidth();
}
//endof getWidth


bool Image::samePixels(const Image& other)
{
	for (int i = 0; i < m_imageData.getHight(); i++)
		for (int j = 0; j < m_imageData.getWidth(); j++)
			if (this->m_imageData.getPixelColor(i, j) !=
				other.m_imageData.getPixelColor(i, j))
				return false;

	return true;
}
//endof samePixels



//----------------------- Local operators ---------------------------

//----------------- operator= ---------------------
Image& Image::operator=(const Image& other)
{
	if (this != &other) {
		m_imageData = other.m_imageData;
	}
	return *this;
}
//endof operator=


//--------------------- operator() ---------------------------
Pixel& Image::operator()
(const unsigned int& row, const unsigned int& col)
{
	return (m_imageData.getPixel(row, col));
}
//endof operator() - for non const


//--------------------- operator() ---------------------------
const Pixel& Image::operator()
(const unsigned int& row, const unsigned int& col) const
{
	return (m_imageData.getPixel(row, col));
}
//endof operator() - for const


//-------------------- operator<< ------------------------------
std::ostream& operator<<(std::ostream& os, const Image& image)
{
	for (int i = 0; i < image.getHight(); i++) {
		for (int j = 0; j < image.getWidth(); j++)
			os << image(i, j);
		os << '\n';
	}

	return os;
}
//endof operator<<



/****************** global Operators *************************/

//------------------- operator== --------------------------
bool operator==(const Image& i1, const Image& i2)
{
	int hight = i1.getHight(),
		width = i1.getWidth();
	if (i1.getHight() != i2.getHight() ||
		i1.getWidth() != i2.getWidth())
		return false;

	for (int row = 0; row < hight; row++)
		for (int col = 0; col < width; col++) 
			if (i1(row, col).getColor() != i2(row, col).getColor())
				return false;
		
	return true;
}
//endof operator==


//------------------- operator!= ---------------------------
bool operator!=(const Image& image1, const Image& image2)
{
	return !(image1 == image2);
}
//endof operator!=


//----------------- operator+ -----------------------------
Image operator+(const Image& image1, const Image& image2)
{
	int hight = std::max(image1.getHight(), image2.getHight()),
		width = image1.getWidth() + image2.getWidth();

	// build the new image.
	Image newImage(hight, width);


	for (int row = 0; row < image1.getHight(); row++)
		for (int col = 0; col < image1.getWidth(); col++)
			newImage(row, col).setColor(image1(0, 0).getColor());


	for (int row = 0; row < image2.getHight(); row++)
		for (int col = image1.getWidth(); col < width; col++)
			newImage(row, col).setColor(image2(0, 0).getColor());


	return newImage;
}
//endof operator+


//------------------- operator+= -----------------------
Image& operator+=(Image& image1, const Image& image2)
{
	return (image1 = image1 + image2);
}
//endof operator+=


//------------------ operator* ----------------------------
Image operator*(const Image& image, const unsigned int& n)
{
	auto newImage = image;

	for (int i = 1; i < n; i++)
		newImage += newImage;

	return newImage;
}
//endof operator* (from right)


//-------------------- 
Image operator*(const unsigned int& n, const Image& image)
{
	return (image * n);
}
//endof operator* (from left)


//----------------- operator*= ---------------------
Image& operator*=(Image& image, const unsigned& n)
{
	return (image = image * n);
}
//endof operator*=


//---------------------- operator| ---------------------------------
Image operator|(const Image& image1, const Image& image2)
{
	int hight = std::max(image1.getHight(), image2.getHight()),
		width = std::max(image1.getWidth(), image2.getWidth()),
		unionHight = std::min(image1.getHight(), image2.getHight()),
		unionwidth = std::min(image1.getWidth(), image2.getWidth());

	// create the union image
	Image unionImage(hight, width);

	// set image1 pixels
	for (int row = 0; row < image1.getHight(); row++)
		for (int col = 0; col < image1.getWidth(); col++)
			unionImage(row, col).setColor(image1(row, col).getColor());

	// set image2 pixels
	for (int row = 0; row < image2.getHight(); row++)
		for (int col = 0; col < image2.getWidth(); col++)
			unionImage(row, col).setColor(image2(row, col).getColor());

	// set the union piexls
	for (int row = 0; row < unionHight; row++)
		for (int col = 0; col < unionwidth; col++)
			unionImage(row, col) = image1(row, col) | image2(row, col);

	return unionImage;
}
//endof opertaot|


//---------------- operator|= ----------------------
Image& operator|=(Image& image1, const Image& image2)
{
	return (image1 = image1 | image2);
}
//endof opertaot|=


//--------------------------- operator& -----------------------------------
// This operator return the intersection of two images.
Image operator&(const Image& image1 , const Image& image2)
{
	int intersectionHight = std::min(image1.getHight(), image2.getHight()),
		intersectionwidth = std::min(image1.getWidth(), image2.getWidth());

	Image intersectioImage(intersectionHight, intersectionwidth);

	// set the intersectio piexls
	for (int row = 0; row < intersectionHight; row++)
		for (int col = 0; col < intersectionwidth; col++)
			intersectioImage(row, col) = image1(row, col) | image2(row, col);

	return intersectioImage;

}
//endof operator&

//------------------- operator&= ----------------------
Image& operator&=(Image& image1, const Image& image2)
{
	return (image1 = image1 & image2);
}
//endof operator&



//--------------------- operator~ ------------------------------
Image operator~(const Image& image)
{
	auto newImage = image;
	int hight = newImage.getHight(),
		width = newImage.getWidth();

	for (int row = 0; row < hight; row++)
		for (int col = 0; col < width; col++)
			if (newImage(row, col).getColor() == BLACK)
				newImage(row, col).setColor(WHITE);
			else if (newImage(row, col).getColor() == WHITE)
				newImage(row, col).setColor(BLACK);

	return newImage;
}
//endof operator~


