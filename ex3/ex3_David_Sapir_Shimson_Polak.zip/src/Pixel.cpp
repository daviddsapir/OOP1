/*********** include section ************/
#include "Pixel.h"
#include "Macros.h"
#include <ostream>



Pixel::Pixel()
	: m_color(' ') 
{}
//endof Pixel

// c-tor
Pixel::Pixel(unsigned char pixel)
	:m_color(' ')
{
	if (pixel == BLACK ||
		pixel == GRAY || 
		pixel == WHITE) {
		m_color = pixel;
	}
}
//endof Pixel


// return the color that the pixel hold.
unsigned char Pixel::getColor() const
{
	return m_color;
}
//endof getColor



//--------------- setColors ------------------------
// This function return the color of a pixel.
void Pixel::setColor(const unsigned char& color)
{
	m_color = color;
}
//endof setColor

// Checks if the color is valid.
bool Pixel::isValidColor(const unsigned char& color) const
{
	return ((color == BLACK || color == GRAY || color == WHITE));
}
//endof isValidColor



//---------------------- operators -----------------------------
bool operator>(const Pixel& p1, const Pixel& p2)
{
	return (p1.getColor() > p2.getColor());
}
//endof operator>


bool operator==(const Pixel& p1, const Pixel& p2)
{
	return (p1.getColor() == p2.getColor());
}
//endof operator==


//------------------- operator!= ------------------
bool operator!=(const Pixel& p1, const Pixel& p2)
{
	return !(p1 == p2);
}
//endof operator!=


//------------------ operator<< ---------------------------
std::ostream& operator<<(std::ostream& os, const Pixel& p)
{
	return (os << p.getColor());
}
//endof operator<<


//----------------- operator| -------------------------
Pixel operator|(const Pixel& p1, const Pixel& p2) {
	if (p1.getColor() >= p2.getColor())
		return p1;
	
	return p2;
}
//endof operator|


//----------------- operator|= ---------------------
Pixel& operator|=(Pixel& p1, const Pixel& p2) {
	p1 = p1 | p2;

	return p1;
}
//endof operator|=



//--------------- operator& -----------------------
Pixel operator&(const Pixel& p1, const Pixel& p2)
{
	if (p1.getColor() <= p2.getColor())
		return p1;

	return p2;
}
//endof operator&


//-------------- operator&= --------------------
Pixel& operator&=(Pixel& p1, const Pixel& p2)
{
	p1 = p1 & p2;

	return p1;
}
//endof operator&=