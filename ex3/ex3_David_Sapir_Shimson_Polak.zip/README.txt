=====================================================================

OOP, ex3
========
by: David Sapir & Shimson Polak 
id: David - 208917351
    Shimson - 315605642 


			Image operators.
=====================================================================

  			Description
                     =================	
This program allows to create image with built in operators 
between images and pixals.
=====================================================================

                       	   Design
                      =================

Pixel
Role:The pixel reprasent 3 colors .Each color is reprasanted by ascii symbols: 
     Black - '219' ,Gray - '176',White - '32' 

ImageDataStructure
Role: Manage 2d dynamic array of Pixels allocation,data and freeing memory that was used.

Image
Role:Reprasant a certain type of Image with 3 color.
     The Image contains an object of ImageDataStructure and allowing change the image , 
     accordingly to the operators that are defined in the class.
=======================================================================

                         Included files
                        =================
There are 3 object files built by us:

1.)Pixel.cpp - This class hold 3 color that are shown in image.

2.)ImageDataStructure.cpp - This class hold the data structure of an image,the data is defined as 
   2d dynamic array of Pixals.

3.)Image.cpp - This class reprasnt a certain image with height ,row and 3 colors.

4.)Macros.h - hold the const used in the files.

Also every '.cpp' file has a header file.
3 source + 4 header = 7 files in total.
=====================================================================

                           Data Structure
                           ==============
-2d dynamic array of size HxW.
=====================================================================

                           Algorithms worth mention:
                         =============================
=====================================================================

			   Known bugs
 		 =============================

=====================================================================

			   Comments
=====================================================================