#pragma once
#include "Pixel.h"

class Image;

class ImageDataStructure {
public:
	ImageDataStructure();
	ImageDataStructure(const unsigned int& h,
		const unsigned int& w,
		const unsigned char& = ' ');
	~ImageDataStructure();

	void setImagePixels(const unsigned char&);
	
	unsigned char getPixelColor(const int&, const int&) const;
	
	void setPixelColor(const int&, const int&, const char& color);
	
	void freeMemory();
	
	void buildImageDataStructure(const int& h,
		const int& w, const unsigned char& pixel);

	// copy function
	void copyImage(const ImageDataStructure&);

	Pixel& getPixel(const unsigned int&, const unsigned int&);

	const Pixel& getPixel
	(const unsigned int&, const unsigned int&) const;

	//------------- global operators ------------------
	ImageDataStructure& operator=(const ImageDataStructure&);


	//----------- get functions --------------
	int getHight()const;
	int getWidth() const;


private:
	Pixel** m_imageData;

	unsigned int m_hight,
		m_width;
};

