#pragma once
#include "ImageDataStructure.h"
#include <iostream>
#include "Pixel.h"
#include "Macros.h"

class Image {
public:
	//------------------- c-tors -------------------------------
	Image();
	Image(const int&, const int&);
	Image(const int&, const int&, const unsigned char pixel);

	//copy c-tor
	Image(const Image&);


	//---------------- Local Operators --------------------

	Image& operator=(const Image&);

	Pixel& operator()(const unsigned int&, const unsigned int&);

	const Pixel& operator()(const unsigned int&, const unsigned int&) const;


	// -------- get functions ----------
	int getHight()const;
	int getWidth()const;


private:
	bool samePixels(const Image&);

	//---------- private members-------------
	ImageDataStructure m_imageData;
};


//---------------- global operators --------------------

bool operator==(const Image&, const Image&);

bool operator!=(const Image&, const Image&);

Image operator+(const Image&, const Image&);

Image& operator+=(Image&, const Image&);

Image operator*(const Image&, const unsigned int&);

Image operator*(const unsigned int&, const Image&);

Image& operator*=(Image&, const unsigned&);

Image operator|(const Image&, const Image&);

Image& operator|=(Image&, const Image&);

Image operator&(const Image&, const Image&);

Image& operator&=(Image&, const Image&);

Image operator~(const Image&);

std::ostream& operator<<(std::ostream& os, const Image& image);