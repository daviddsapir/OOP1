#pragma once
#include <iosfwd>


class Pixel {
public:

	//---------- c-tors ----------------
	//delete the default c-tor
	Pixel();

	Pixel(unsigned char pixel);
	~Pixel(){}

	unsigned char getColor() const;
	void setColor(const unsigned char& color);

private:
	bool isValidColor(const unsigned char& pixel) const;

	char m_color;
};


//------------------- global function & operators ----------------------
bool operator==(const Pixel& p1, const Pixel& p2);

bool operator!=(const Pixel& p1, const Pixel& p2);

std::ostream& operator<<(std::ostream& os, const Pixel& p);

Pixel operator|(const Pixel& p1, const Pixel& p2);

Pixel operator&(const Pixel& p1, const Pixel& p2);

Pixel& operator|=(Pixel& p1, const Pixel& p2);

Pixel& operator&=(Pixel& p1, const Pixel& p2);